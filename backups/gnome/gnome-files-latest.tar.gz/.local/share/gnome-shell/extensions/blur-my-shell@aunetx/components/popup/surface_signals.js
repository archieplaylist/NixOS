import Meta from 'gi://Meta';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

const SURFACE_SIGNALS = [
    'notify::allocation',
    'notify::position',
    'notify::size',
    'notify::x',
    'notify::y',
    'notify::width',
    'notify::height',
    'notify::clip-rect',
    'notify::visible',
    'notify::mapped',
    'notify::opacity',
    'notify::translation-x',
    'notify::translation-y',
    'notify::scale-x',
    'notify::scale-y',
    'notify::pseudo-class',
]; 

export const PopupBlurSurfaceSignals = class PopupBlurSurfaceSignals {
    constructor(surface) {
        this.surface = surface;
        this.signal_ids = [];
        this.signal_actors = new WeakSet();
        this.destroyed_actors = new WeakSet();
    }

    connect_actor(actor) {
        if (!actor || this.signal_actors.has(actor))
            return;

        this.signal_actors.add(actor);
        this.track_destroy(actor);

        const is_heavy_surface = this.surface.is_heavy_surface();

        SURFACE_SIGNALS.forEach(signal => {
            let id = actor.connect(signal, () => {
                this.clear_pending_idles();
                const is_visibility_change = signal === 'notify::visible' || signal === 'notify::mapped';
                if (is_heavy_surface || is_visibility_change) {
                    this.surface.queue_update();
                    return;
                }
                else {
                    this.updateId = global.compositor.get_laters().add(Meta.LaterType.IDLE, () => {
                        this.updateId = 0;
                        this.surface.queue_update();
                        return false;
                    });
                }
            });
            this.signal_ids.push([actor, id, signal]);
        });
    }

    track_destroy(actor) {
        const id = actor.connect('destroy', () => this.destroyed_actors.add(actor));
        this.signal_ids.push([actor, id]);
    }

    connect_ancestors(actor) {
        actor = actor ? actor.get_parent() : null;

        while (actor && actor !== this.surface.parent) {
            this.connect_actor(actor);
            actor = actor.get_parent();
        }
    }

    connect_layout() {
        if (!this.surface.static_blur)
            return;

        this.signal_ids.push([
            Main.layoutManager,
            Main.layoutManager.connect('monitors-changed', () => this.surface.queue_update()),
        ]);
    }

    connect_settings() {
        [
            this.surface.corner_radius.key,
            'override-background',
            'style-popup',
        ].forEach(key => {
            const id = this.surface.settings.popup.settings.connect(
                `changed::${key}`,
                () => this.surface.update_settings()
            );
            this.signal_ids.push([this.surface.settings.popup.settings, id]);
        });
    }

    clear_pending_idles() {
        if (this.updateId) {
            global.compositor.get_laters().remove(this.updateId);
            this.updateId = 0;
        }
    }

    disconnect_all() {
        this.clear_pending_idles();
        this.signal_ids.forEach(([signal_actor, signal_id]) => {
            if (this.destroyed_actors.has(signal_actor))
                return;

            signal_actor.disconnect(signal_id);
        });
        this.signal_ids = [];
        this.signal_actors = new WeakSet();
        this.destroyed_actors = new WeakSet();
    }
};
