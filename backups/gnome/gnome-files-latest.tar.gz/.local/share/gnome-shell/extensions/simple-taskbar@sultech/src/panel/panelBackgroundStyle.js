// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (C) 2026 sultech

import Cogl from 'gi://Cogl';

import {panelPosition} from './panelPosition.js';
import {panelTransparencyOpacity} from './dynamicTransparency.js';

const DARK_BORDER_COLOR = '255, 255, 255';
const LIGHT_BORDER_COLOR = '0, 0, 0';
const BORDER_OPACITY = 0.20;
const BORDER_WIDTHS = [1, 2];
const PIXEL_EPSILON = 0.001;

function colorComponents(value) {
    const [, color] = Cogl.Color.from_string(value);
    return `${color.red}, ${color.green}, ${color.blue}`;
}

function panelBackgroundColor(settings, light) {
    if (!settings.get_boolean('custom-panel-color-enabled'))
        return light ? '224, 229, 238' : '24, 24, 27';

    return colorComponents(settings.get_string('custom-panel-color'));
}

export function panelBorderWidth(scale) {
    return BORDER_WIDTHS.find(width =>
        Math.abs(width * scale - Math.round(width * scale)) < PIXEL_EPSILON) ??
        BORDER_WIDTHS[0];
}

export function panelBorderStyle(settings, light, borderEnabled,
    fullBorder = false, important = false, borderWidth = 1) {
    const position = panelPosition(settings);
    const borderColor = light
        ? LIGHT_BORDER_COLOR
        : DARK_BORDER_COLOR;
    const priority = important ? ' !important' : '';
    let borderStyle =
        `border-top: 0${priority}; ` +
        `border-bottom: 0${priority}; ` +
        `border-left: 0${priority}; ` +
        `border-right: 0${priority}; `;
    if (borderEnabled && fullBorder) {
        borderStyle += `border: ${borderWidth}px solid ` +
            `rgba(${borderColor}, ${BORDER_OPACITY.toFixed(3)})` +
            `${priority}; `;
    } else if (borderEnabled) {
        const borderEdge = {
            top: 'bottom',
            bottom: 'top',
            left: 'right',
            right: 'left',
        }[position];
        borderStyle += `border-${borderEdge}: 1px solid ` +
            `rgba(${borderColor}, ${BORDER_OPACITY.toFixed(3)})` +
            `${priority}; `;
    }
    return borderStyle;
}

export function panelBackgroundStyle(settings, light, borderEnabled,
    originalStyle = '', fullBorder = false, dynamicOpacity = null,
    transitionDuration = 0, borderWidth = 1) {
    const opacity = dynamicOpacity ?? panelTransparencyOpacity(settings);
    const background = panelBackgroundColor(settings, light);
    const borderStyle = panelBorderStyle(
        settings,
        light,
        borderEnabled && dynamicOpacity !== 0,
        fullBorder,
        false,
        borderWidth
    );
    const gradientEnabled =
        settings.get_boolean('custom-panel-color-enabled') &&
        settings.get_boolean('custom-panel-gradient-enabled');
    const backgroundStyle = gradientEnabled
        ? 'background-color: transparent !important; ' +
            `background-gradient-direction: ${settings.get_string(
                'custom-panel-gradient-direction'
            )} !important; ` +
            `background-gradient-start: rgba(${background}, ` +
            `${opacity.toFixed(2)}) !important; ` +
            `background-gradient-end: rgba(${colorComponents(
                settings.get_string('custom-panel-gradient-color')
            )}, ${opacity.toFixed(2)}) !important; `
        : `background-color: rgba(${background}, ` +
            `${opacity.toFixed(2)}) !important; `;
    const transitionStyle = transitionDuration > 0
        ? `transition-duration: ${transitionDuration}ms; `
        : '';
    const transparencyStyle = backgroundStyle +
        borderStyle +
        transitionStyle +
        'box-shadow: none;';
    const separator = originalStyle.endsWith(';') ? ' ' : '; ';
    return originalStyle
        ? `${originalStyle}${separator}${transparencyStyle}`
        : transparencyStyle;
}
