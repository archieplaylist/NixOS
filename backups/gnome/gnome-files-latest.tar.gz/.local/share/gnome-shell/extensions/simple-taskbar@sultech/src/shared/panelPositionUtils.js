// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (C) 2026 sultech

const PANEL_POSITIONS = Object.freeze([
    'top',
    'bottom',
    'left',
    'right',
]);

export function alternativePanelPosition(position) {
    return PANEL_POSITIONS.find(candidate => candidate !== position);
}

export function panelPosition(settings) {
    return settings.get_string('panel-position');
}

export function activePanelPosition(settings) {
    return settings.get_boolean('dock-mode')
        ? settings.get_string('dock-position')
        : settings.get_string('panel-position');
}

export function panelIsTop(settings) {
    return panelPosition(settings) === 'top';
}

export function positionIsVertical(position) {
    return position === 'left' || position === 'right';
}

export function panelIsVertical(settings) {
    return positionIsVertical(panelPosition(settings));
}

export function panelIsMinimumEdge(settings) {
    const position = panelPosition(settings);
    return position === 'top' || position === 'left';
}
