// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (C) 2026 sultech

import {
    getWindowsXpPanelItemOrder,
} from './panelItemOrder.js';
import {APP_ICON_HOVER_ANIMATION} from './applicationHoverAnimation.js';
import {applySharedInteractionDefaults} from './interactionDefaults.js';
import {
    setBoolean,
    setInteger,
    setString,
    setStringArray,
} from './settingsUtils.js';

export const WINDOWS_XP_PANEL_HEIGHT = 30;
export const WINDOWS_XP_ICON_SIZE = 16;
export const WINDOWS_XP_ICON_SPACING = -5;
export const WINDOWS_XP_ALIGNMENT = 'left';
export const WINDOWS_XP_COMBINE_MODE = 'when-full';
export const WINDOWS_XP_PANEL_POSITION = 'bottom';
export const WINDOWS_XP_CLOCK_POSITION = 'right';
export const WINDOWS_XP_SYSTEM_MENU_POSITION = 'right';

export function applyWindowsXpThemeAppearance(settings) {
    setBoolean(settings, 'panel-theme-follow-system', false);
    setString(settings, 'panel-theme', 'dark');
}

export function applyWindowsXpThemeBehaviorDefaults(settings) {
    applySharedInteractionDefaults(settings);
    setBoolean(settings, 'hot-edge-overview-enabled', true);
    setBoolean(settings, 'multi-monitor-panels', true);
    setBoolean(settings, 'tray-overflow-enabled', true);
    setBoolean(settings, 'folder-menu-enabled', false);
    setBoolean(settings, 'panel-menu-click-only', true);
    setBoolean(settings, 'notification-banner-bottom-end', true);
    setBoolean(settings, 'hide-dash-enabled', true);
    setBoolean(settings, 'launch-to-desktop-enabled', true);
}

export function applyWindowsXpThemeSettings(settings) {
    setBoolean(settings, 'panel-height-follow-icon-size', false);
    setInteger(settings, 'panel-height', WINDOWS_XP_PANEL_HEIGHT);
    setInteger(settings, 'panel-button-padding', 0);
    setInteger(settings, 'icon-size', WINDOWS_XP_ICON_SIZE);
    setInteger(settings, 'icon-spacing', WINDOWS_XP_ICON_SPACING);
    setString(settings, 'app-alignment', WINDOWS_XP_ALIGNMENT);
    setString(settings, 'panel-position', WINDOWS_XP_PANEL_POSITION);
    setString(settings, 'clock-position', WINDOWS_XP_CLOCK_POSITION);
    setString(
        settings,
        'system-menu-position',
        WINDOWS_XP_SYSTEM_MENU_POSITION
    );
    setString(
        settings,
        'tray-overflow-position',
        WINDOWS_XP_SYSTEM_MENU_POSITION
    );
    setString(
        settings,
        'folder-menu-position',
        WINDOWS_XP_SYSTEM_MENU_POSITION
    );
    setString(settings, 'show-desktop-button-position', 'left');
    if (settings.get_string('activities-button-position') === 'center')
        setString(settings, 'activities-button-position', 'left');
    setStringArray(
        settings,
        'panel-item-order',
        getWindowsXpPanelItemOrder(
            settings.get_strv('panel-item-order'),
            settings.get_string('activities-button-position')
        )
    );
    setString(
        settings,
        'start-button-position',
        WINDOWS_XP_ALIGNMENT
    );
    setBoolean(settings, 'use-pinned-apps-as-launchers', true);
    setBoolean(settings, 'hide-unpinned-taskbar-apps', false);
    setBoolean(settings, 'show-pinned-app-separator', false);
    setBoolean(settings, 'show-location-separator', false);
    setBoolean(settings, 'show-start-button-separator', false);
    setBoolean(settings, 'start-menu-running-indicators', false);
    setBoolean(settings, 'windows-start-menu-enabled', true);
    setBoolean(settings, 'clock-visible', true);
    setBoolean(settings, 'transparency-enabled', false);
    setBoolean(settings, 'start-menu-follow-panel-transparency', false);
    setBoolean(settings, 'start-menu-super-key', true);
    setBoolean(settings, 'custom-indicator-colors-enabled', false);
    setBoolean(settings, 'match-icon-color', false);
    setBoolean(settings, 'custom-panel-color-enabled', false);
    setBoolean(settings, 'panel-border-enabled', false);
    setBoolean(settings, 'panel-border-light-enabled', false);
    setBoolean(settings, 'application-overflow-enabled', true);
    setBoolean(settings, 'hide-app-labels', false);
    setString(
        settings,
        'animate-appicon-hover-animation-type',
        APP_ICON_HOVER_ANIMATION.NONE
    );
    if (settings.get_string('combine-app-buttons-mode') === 'always') {
        setString(
            settings,
            'combine-app-buttons-mode',
            WINDOWS_XP_COMBINE_MODE
        );
    }
}
