// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (C) 2026 sultech

import Adw from 'gi://Adw';
import {gettext as _} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

import {PANEL_SCROLL_ACTION} from '../shared/panelScrollActions.js';
import {getPanelScrollActionChoices} from './taskbarBehaviorGroup.js';
import {
    addComboRow,
    addSpinRow,
    createSwitchRow,
} from './preferencesWidgets.js';
import {createBottomHotEdgeRow} from './bottomHotEdgeRow.js';
import {addWindowDodgeRows} from './windowDodgeGroup.js';

export function addDockBehaviorGroup({page, settings, connectSettings}) {
    const group = new Adw.PreferencesGroup({
        title: _('Dock Behavior'),
        description: _('Configure Dock interaction independently of the taskbar.'),
    });
    page.add(group);

    const autoHideSwitch = createSwitchRow(settings, {
        key: 'dock-autohide-enabled',
        title: _('Auto-hide Dock'),
        subtitle: _('Reveal the Dock when the pointer reaches its screen edge'),
    });
    const edgeRevealSwitch = createSwitchRow(settings, {
        key: 'dock-edge-reveal-enabled',
        title: _('Limit Reveal to Dock Edge'),
        subtitle: _('Only reveal a floating Dock when the pointer reaches its edge'),
    });
    const dodgeWindows = addWindowDodgeRows(
        group,
        settings,
        {
            enabledKey: 'dock-dodge-windows-enabled',
            modeKey: 'dock-dodge-windows-mode',
            pointerRevealKey: 'dock-dodge-pointer-reveal-enabled',
            autohideKey: 'dock-autohide-enabled',
            autohideSwitch: autoHideSwitch,
            visibilityTitle: _('Dock Auto-hide and Window Dodge'),
            visibilitySubtitle: _(
                'Choose when the Dock hides and how it is revealed'
            ),
            dodgeSubtitle: _(
                'Hide the Dock when a qualifying window overlaps it'
            ),
            modeSubtitle: _('Choose which windows make the Dock hide'),
            pointerRevealSubtitle: _(
                'Let the pointer reveal the hidden Dock at its screen edge'
            ),
            timingDescriptions: {
                reveal: _(
                    'Choose how quickly the pointer brings the Dock back'
                ),
                revealMode: _(
                    'Choose when the Dock appears at the screen edge'
                ),
                hide: _('Choose how soon the Dock hides again'),
                hideDelay: _(
                    'How long the Dock waits after the pointer leaves, in milliseconds'
                ),
            },
            visibilityRows: [edgeRevealSwitch],
            connectSettings,
        }
    );

    group.add(createBottomHotEdgeRow(settings, connectSettings));

    const workspaceScrollRow = new Adw.ExpanderRow({
        title: _('Dock Scroll'),
        subtitle: _('Configure scrolling over empty Dock space'),
    });
    const workspaceScrollActionRow = addComboRow(
        workspaceScrollRow,
        settings,
        {
            key: 'dock-workspace-scroll-action',
            title: _('Scroll Action'),
            subtitle: _('Action used when scrolling over empty Dock space'),
            choices: getPanelScrollActionChoices(),
            addRow: row => workspaceScrollRow.add_row(row),
        },
        connectSettings
    );

    const workspaceScrollDelayRow = addSpinRow(
        workspaceScrollRow,
        settings,
        {
            key: 'dock-workspace-scroll-delay',
            title: _('Scroll Delay'),
            subtitle: _('Minimum delay between Dock scroll actions in milliseconds'),
            lower: 5,
            upper: 250,
            step: 5,
            addRow: row => workspaceScrollRow.add_row(row),
        },
        connectSettings
    );
    group.add(workspaceScrollRow);

    const multiMonitorSwitch = createSwitchRow(settings, {
        key: 'dock-multi-monitor-panels',
        title: _('Show Dock on All Monitors'),
        subtitle: _('Show the Dock on every connected monitor'),
    });
    group.add(multiMonitorSwitch);

    const syncWorkspaceScrollControls = () => {
        workspaceScrollActionRow.sensitive = group.sensitive;
        workspaceScrollDelayRow.sensitive = group.sensitive &&
            settings.get_string('dock-workspace-scroll-action') !==
                PANEL_SCROLL_ACTION.DO_NOTHING;
    };
    const syncAvailability = () => {
        const available = settings.get_boolean('dock-mode') &&
            !settings.get_boolean('windows-xp-theme-enabled');
        group.sensitive = available;
        edgeRevealSwitch.sensitive = available &&
            !settings.get_boolean('dock-panel-mode');
        dodgeWindows.syncAvailability();
        syncWorkspaceScrollControls();
    };
    for (const key of [
        'dock-mode',
        'dock-panel-mode',
        'windows-xp-theme-enabled',
    ]) {
        connectSettings(settings, `changed::${key}`, syncAvailability);
    }
    connectSettings(
        settings,
        'changed::dock-workspace-scroll-action',
        syncWorkspaceScrollControls
    );
    syncAvailability();
}
