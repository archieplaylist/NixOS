// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (C) 2026 sultech

import Gio from 'gi://Gio';
import GObject from 'gi://GObject';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import {isDefaultPanelWithoutDock} from '../shared/panelModeProfiles.js';
import {normalizeAccelerator} from '../shared/keybindingUtils.js';

const SUPER_KEY_SETTING = 'start-menu-super-key';
const SUPER_TAB_KEYBINDING = 'start-menu-super-tab-hotkey';
const CUSTOM_KEYBINDING = 'start-menu-custom-hotkey';
const FILE_MANAGER_SETTING = 'super-e-file-manager-enabled';
const FILE_MANAGER_KEYBINDING = 'super-e-file-manager-hotkey';
const DISPLACED_OVERLAY_KEY = 'start-menu-displaced-overlay-key';
const OVERLAY_KEY = 'overlay-key';
const ACTION_MODES = Shell.ActionMode.NORMAL |
    Shell.ActionMode.OVERVIEW |
    Shell.ActionMode.POPUP;
const DEFAULT_OVERLAY_ACTION_MODES = Shell.ActionMode.NORMAL |
    Shell.ActionMode.OVERVIEW;

export class StartMenuKeybindings {
    constructor(
        settings,
        toggleMenu,
        toggleOverview,
        openFileManager,
        switcherKeybindings
    ) {
        this._settings = settings;
        this._toggleMenu = toggleMenu;
        this._toggleOverview = toggleOverview;
        this._openFileManager = openFileManager;
        this._switcherKeybindings = switcherKeybindings;
        this._mutterSettings = new Gio.Settings({
            schema_id: 'org.gnome.mutter',
        });
        this._superTabMode = null;
        this._superTabAction = Meta.KeyBindingAction.NONE;
        this._customEnabled = false;
        this._fileManagerEnabled = false;
        this._overlayEnabled = false;
        this._overlayHandlerId = 0;
        this._overlaySettingChangedId = 0;
        this._defaultOverlayHandlerId = 0;
        this._startupCompleteId = 0;
    }

    sync() {
        this._syncFileManager();
        if (!this._startMenuAvailable()) {
            this._disableStartMenuBindings();
            return;
        }

        if (this._settings.get_boolean(SUPER_KEY_SETTING)) {
            this._disableCustom();
            if (!this._enableSuperTab('overview') ||
                !this._enableOverlayKey()) {
                this._disableSuperTab();
                this._disableOverlayKey();
                this._disableSuperKeySetting();
            }
            return;
        }

        this._disableOverlayKey();
        if (this._settings.get_boolean('start-menu-super-tab')) {
            this._disableCustom();
            this._enableSuperTab('start-menu');
            return;
        }

        this._disableSuperTab();
        if (this._settings.get_strv(CUSTOM_KEYBINDING).length > 0)
            this._enableCustom();
        else
            this._disableCustom();
    }

    customAcceleratorChanged() {
        this._disableCustom();
        this.sync();
    }

    disable() {
        this._disableStartMenuBindings();
        this._disableFileManager();
    }

    destroy() {
        this.disable();
        this._mutterSettings = null;
        this._switcherKeybindings = null;
        this._settings = null;
        this._toggleMenu = null;
        this._toggleOverview = null;
        this._openFileManager = null;
    }

    _disableStartMenuBindings() {
        this._disableSuperTab();
        this._disableOverlayKey();
        this._disableCustom();
    }

    _startMenuAvailable() {
        return this._settings.get_boolean('windows-start-menu-enabled') &&
            !isDefaultPanelWithoutDock(this._settings);
    }

    _syncFileManager() {
        if (!this._settings.get_boolean(FILE_MANAGER_SETTING)) {
            this._disableFileManager();
            return;
        }
        if (this._fileManagerEnabled)
            return;

        const action = Main.wm.addKeybinding(
            FILE_MANAGER_KEYBINDING,
            this._settings,
            Meta.KeyBindingFlags.IGNORE_AUTOREPEAT,
            ACTION_MODES,
            () => this._openFileManager()
        );
        this._fileManagerEnabled = action !== Meta.KeyBindingAction.NONE;
        if (!this._fileManagerEnabled) {
            this._reportFailure(
                'Super+E file manager shortcut could not be registered'
            );
        }
    }

    _disableFileManager() {
        if (!this._fileManagerEnabled)
            return;

        Main.wm.removeKeybinding(FILE_MANAGER_KEYBINDING);
        this._fileManagerEnabled = false;
    }

    _enableSuperTab(mode) {
        if (this._superTabMode === mode)
            return true;

        this._disableSuperTab();
        this._superTabMode = mode;
        this._switcherKeybindings.setSuperTabHandler(
            () => this._activateSuperTab()
        );
        this._superTabAction = Main.wm.addKeybinding(
            SUPER_TAB_KEYBINDING,
            this._settings,
            Meta.KeyBindingFlags.IGNORE_AUTOREPEAT,
            ACTION_MODES,
            () => this._activateSuperTab()
        );
        return true;
    }

    _disableSuperTab() {
        if (this._superTabAction !== Meta.KeyBindingAction.NONE)
            Main.wm.removeKeybinding(SUPER_TAB_KEYBINDING);
        this._superTabAction = Meta.KeyBindingAction.NONE;
        this._superTabMode = null;
        this._switcherKeybindings.setSuperTabHandler(null);
    }

    _activateSuperTab() {
        if (this._superTabMode === 'overview')
            this._toggleOverview();
        else
            this._toggleMenu();
    }

    _enableOverlayKey() {
        if (this._overlayEnabled)
            return true;

        this._saveOverlayKey();
        this._mutterSettings.set_string(OVERLAY_KEY, 'Super');
        Main.wm.allowKeybinding(OVERLAY_KEY, ACTION_MODES);
        this._overlayEnabled = true;
        this._overlaySettingChangedId = this._mutterSettings.connect(
            `changed::${OVERLAY_KEY}`,
            () => this._overlayKeyChanged()
        );
        if (Main.layoutManager._startingUp) {
            this._startupCompleteId = Main.layoutManager.connect(
                'startup-complete',
                () => {
                    this._startupCompleteId = 0;
                    if (this._overlayEnabled && !this._installOverlayHandler())
                        this._overlayInstallationFailed();
                }
            );
            return true;
        }

        if (this._installOverlayHandler())
            return true;

        this._disableOverlayKey();
        return false;
    }

    _installOverlayHandler() {
        const handlerId = GObject.signal_handler_find(global.display, {
            signalId: OVERLAY_KEY,
        });
        if (!handlerId) {
            this._reportFailure('GNOME overlay-key handler was not found');
            return false;
        }

        GObject.signal_handler_block(global.display, handlerId);
        this._defaultOverlayHandlerId = handlerId;
        this._overlayHandlerId = global.display.connect(
            OVERLAY_KEY,
            () => {
                this._toggleMenu();
                Main.wm.allowKeybinding(OVERLAY_KEY, ACTION_MODES);
            }
        );
        return true;
    }

    _overlayInstallationFailed() {
        this._disableSuperTab();
        this._disableOverlayKey();
        this._disableSuperKeySetting();
    }

    _disableOverlayKey() {
        this._overlayEnabled = false;
        if (this._overlaySettingChangedId) {
            this._mutterSettings.disconnect(
                this._overlaySettingChangedId
            );
            this._overlaySettingChangedId = 0;
        }
        if (this._startupCompleteId) {
            Main.layoutManager.disconnect(this._startupCompleteId);
            this._startupCompleteId = 0;
        }
        if (this._overlayHandlerId) {
            global.display.disconnect(this._overlayHandlerId);
            this._overlayHandlerId = 0;
        }
        this._unblockDefaultOverlayHandler();
        Main.wm.allowKeybinding(
            OVERLAY_KEY,
            DEFAULT_OVERLAY_ACTION_MODES
        );
        this._restoreOverlayKey();
    }

    _overlayKeyChanged() {
        const overlayKey = this._mutterSettings.get_string(OVERLAY_KEY);
        if (overlayKey === 'Super')
            return;

        this._settings.set_strv(DISPLACED_OVERLAY_KEY, [overlayKey]);
        GObject.signal_handler_block(
            this._mutterSettings,
            this._overlaySettingChangedId
        );
        this._mutterSettings.set_string(OVERLAY_KEY, 'Super');
        GObject.signal_handler_unblock(
            this._mutterSettings,
            this._overlaySettingChangedId
        );
    }

    _saveOverlayKey() {
        if (this._settings.get_strv(DISPLACED_OVERLAY_KEY).length > 0)
            return;

        this._settings.set_strv(DISPLACED_OVERLAY_KEY, [
            this._mutterSettings.get_string(OVERLAY_KEY),
        ]);
    }

    _restoreOverlayKey() {
        const [overlayKey] = this._settings.get_strv(
            DISPLACED_OVERLAY_KEY
        );
        if (overlayKey === undefined)
            return;

        this._mutterSettings.set_string(OVERLAY_KEY, overlayKey);
        this._settings.set_strv(DISPLACED_OVERLAY_KEY, []);
    }

    _unblockDefaultOverlayHandler() {
        if (!this._defaultOverlayHandlerId)
            return;

        if (GObject.signal_handler_is_connected(
            global.display,
            this._defaultOverlayHandlerId
        )) {
            GObject.signal_handler_unblock(
                global.display,
                this._defaultOverlayHandlerId
            );
        }
        this._defaultOverlayHandlerId = 0;
    }

    _disableSuperKeySetting() {
        if (this._settings.get_boolean(SUPER_KEY_SETTING))
            this._settings.set_boolean(SUPER_KEY_SETTING, false);
    }

    _enableCustom() {
        const accelerators = this._settings.get_strv(CUSTOM_KEYBINDING);
        if (this._customConflictsWithManagedShortcut(accelerators)) {
            this._disableCustom();
            this._reportFailure(
                'Custom Start menu shortcut conflicts with another Simple Taskbar shortcut'
            );
            return;
        }
        if (this._customEnabled)
            return;

        const action = Main.wm.addKeybinding(
            CUSTOM_KEYBINDING,
            this._settings,
            Meta.KeyBindingFlags.IGNORE_AUTOREPEAT,
            ACTION_MODES,
            () => this._toggleMenu()
        );
        this._customEnabled = action !== Meta.KeyBindingAction.NONE;
        if (!this._customEnabled) {
            this._reportFailure(
                'Custom Start menu shortcut could not be registered'
            );
        }
    }

    _disableCustom() {
        if (!this._customEnabled)
            return;

        Main.wm.removeKeybinding(CUSTOM_KEYBINDING);
        this._customEnabled = false;
    }

    _customConflictsWithManagedShortcut(accelerators) {
        const managed = [];
        if (this._settings.get_boolean('grid-alt-tab-enabled')) {
            managed.push(
                ...this._settings.get_strv('grid-alt-tab-hotkey'),
                ...this._settings.get_strv(
                    'grid-alt-tab-backward-hotkey'
                )
            );
        }
        if (this._settings.get_boolean(FILE_MANAGER_SETTING)) {
            managed.push(
                ...this._settings.get_strv(FILE_MANAGER_KEYBINDING)
            );
        }
        const managedSet = new Set(managed.map(normalizeAccelerator));
        return accelerators.some(accelerator =>
            managedSet.has(normalizeAccelerator(accelerator)));
    }

    _reportFailure(message) {
        console.warn(`Simple Taskbar: ${message}`);
    }
}
