// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (C) 2026 sultech

import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import Pango from 'gi://Pango';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

import {
    panelArrowSide,
    panelIsTop,
    panelPosition,
    positionIsVertical,
} from '../panel/panelPosition.js';
import {
    closePopupMenu,
    openPopupMenu,
} from '../popupMenuUtils.js';
import {HOVER_ACTION} from '../shared/applicationHoverActions.js';
import {panelUsesLightTheme} from '../themeUtils.js';
import {getScrollDelta} from '../scrollUtils.js';
import {pointerButtonIsPressed} from '../pointerUtils.js';
import {windowsForTaskbarItem} from './taskbarItemWindows.js';

const PREVIEW_WIDTH = 260;
const PREVIEW_HEIGHT = 146;
const PREVIEW_PEEK_DURATION = 250;
const APP_TOOLTIP_DELAY = 300;
const APP_TOOLTIP_SHOW_TIME = 150;
const APP_TOOLTIP_HIDE_TIME = 100;
const APP_TOOLTIP_CLOSE_DELAY = 300;

export class WindowPreviewController {
    constructor(
        getTaskbarItems,
        getInterestingWindows,
        settings,
        onPreviewActivated,
        getHoverAnimationOutwardReserve,
        isPointerInMagnifyBounds
    ) {
        this._getTaskbarItems = getTaskbarItems;
        this._getInterestingWindows = getInterestingWindows;
        this._settings = settings;
        this._onPreviewActivated = onPreviewActivated;
        this._getHoverAnimationOutwardReserve =
            getHoverAnimationOutwardReserve;
        this._isPointerInMagnifyBounds = isPointerInMagnifyBounds;
        this._previewItem = null;
        this._previewItemDestroyId = 0;
        this._previewPendingItem = null;
        this._previewOpenId = 0;
        this._previewCloseId = 0;
        this._previewSwitchId = 0;
        this._previewSwitchItem = null;
        this._previewSwitchItemDestroyId = 0;
        this._previewRefreshId = 0;
        this._previewHoverItem = null;
        this._peekTimeoutId = 0;
        this._peekedWindow = null;
        this._peekedWindowStack = null;
        this._closingPreviewMenus = new Set();
        this._appTooltip = null;
        this._tooltipItem = null;
        this._tooltipItemDestroyId = 0;
        this._tooltipTimeoutId = 0;
        this._tooltipCloseId = 0;
        this._peekModeChangedId = settings.connect(
            'changed::peek-mode',
            () => {
                this._clearTimeout('_peekTimeoutId');
                if (!settings.get_boolean('peek-mode'))
                    this._restorePeek();
            }
        );
        this._hoverActionChangedId = settings.connect(
            'changed::application-hover-action',
            () => {
                const item = this._taskbarItemAtPointer();
                if (this.hoverAction === HOVER_ACTION.SHOW_PREVIEWS) {
                    this.hideTooltip();
                    if (!item)
                        return;
                    if (this._windowsForItem(item).length > 0)
                        this.schedule(item);
                    else
                        this.scheduleTooltip(item);
                    return;
                }

                this.hide();
                if (this.hoverAction === HOVER_ACTION.SHOW_TOOLTIP && item)
                    this.scheduleTooltip(item);
                else
                    this.hideTooltip();
            }
        );
        this._overviewShowingId = Main.overview.connect('showing', () => {
            this.hideTooltip(false);
            this.hide();
        });
    }

    get currentItem() {
        return this._previewItem;
    }

    get hoverItem() {
        return this._previewHoverItem;
    }

    get tooltipItem() {
        return this._tooltipItem;
    }

    get isOpen() {
        return Boolean(
            this._previewItem || this._closingPreviewMenus.size > 0
        );
    }

    get hoverAction() {
        return this._settings.get_string('application-hover-action');
    }

    destroy() {
        this._clearTimeouts();
        this._clearTimeout('_tooltipTimeoutId');
        this._clearTimeout('_tooltipCloseId');
        Main.overview.disconnect(this._overviewShowingId);
        this._overviewShowingId = 0;
        this._settings.disconnect(this._hoverActionChangedId);
        this._hoverActionChangedId = 0;
        this._settings.disconnect(this._peekModeChangedId);
        this._peekModeChangedId = 0;
        this._hideTooltip(false);
        this._hidePreview(false);
        this._appTooltip?.destroy();
        this._appTooltip = null;

        const closingMenus = [...this._closingPreviewMenus];
        this._closingPreviewMenus.clear();
        for (const menu of closingMenus)
            menu.destroy();

        this._getTaskbarItems = null;
        this._getInterestingWindows = null;
        this._onPreviewActivated = null;
        this._getHoverAnimationOutwardReserve = null;
        this._isPointerInMagnifyBounds = null;
        this._settings = null;
        this._previewHoverItem = null;
    }

    removeItem(item) {
        if (this._previewPendingItem === item)
            this._clearTimeout('_previewOpenId');
        if (this._previewSwitchItem === item)
            this._clearSwitch();
        if (this._previewHoverItem === item)
            this._previewHoverItem = null;
        if (this._tooltipItem === item)
            this.hideTooltip();
        if (this._previewItem === item)
            this.hide();
    }

    destroyButton(button) {
        if (this._previewItem?._taskbarButton === button)
            this.hide();
        else
            button._taskbarPreviewMenu?.destroy();
        button._taskbarPreviewMenu = null;
        button._taskbarPreviewBox = null;
    }

    windowsChanged(app) {
        if (this._previewItem?._taskbarApp === app)
            this._queueRefresh(app);
        if (this._tooltipItem?._taskbarApp === app)
            this.hideTooltip();
    }

    schedule(item) {
        this._clearTimeout('_previewCloseId');
        this._clearTimeout('_previewOpenId');
        if (this.hoverAction !== HOVER_ACTION.SHOW_PREVIEWS)
            return;
        if (this._overviewIsVisible()) {
            this.hide();
            return;
        }
        if (this._windowsForItem(item).length === 0)
            return;
        if (this._previewItem === item)
            return;

        this._previewPendingItem = item;
        this._previewOpenId = GLib.timeout_add(
            GLib.PRIORITY_DEFAULT,
            this._settings.get_int('show-window-previews-timeout'),
            () => {
                this._previewOpenId = 0;
                this._previewPendingItem = null;
                this.show(item);
                return GLib.SOURCE_REMOVE;
            }
        );
    }

    scheduleClose() {
        this._clearTimeout('_previewOpenId');
        if (!this._previewItem || this._previewCloseId)
            return;
        this._previewCloseId = GLib.timeout_add(
            GLib.PRIORITY_DEFAULT,
            this._settings.get_int('leave-timeout'),
            () => {
                if (this._pointerIsOverPreview(this._previewItem)) {
                    this._previewCloseId = 0;
                    return GLib.SOURCE_REMOVE;
                }
                if (this.isPointerInMagnifyBounds() &&
                    this._taskbarItemAtPointer() === this._previewItem)
                    return GLib.SOURCE_CONTINUE;
                this._previewCloseId = 0;
                this.hide(true);
                return GLib.SOURCE_REMOVE;
            }
        );
    }

    scheduleSwitch(item) {
        this._clearTimeout('_previewOpenId');
        this._clearTimeout('_previewCloseId');
        if (this.hoverAction !== HOVER_ACTION.SHOW_PREVIEWS) {
            this.hide();
            return;
        }
        if (this._overviewIsVisible()) {
            this.hide();
            return;
        }
        if (this._previewSwitchItem === item)
            return;

        this._clearSwitch();
        this._setPreviewSwitchItem(item);
        this._previewSwitchId = GLib.idle_add(GLib.PRIORITY_HIGH_IDLE, () => {
            this._previewSwitchId = 0;
            const target = this._previewSwitchItem;
            this._setPreviewSwitchItem(null);
            if (target && target.mapped)
                this.show(target);
            return GLib.SOURCE_REMOVE;
        });
    }

    scheduleTooltip(item) {
        this._clearTimeout('_tooltipCloseId');
        if (this._tooltipItem === item &&
            (this._tooltipTimeoutId || this._appTooltip?.visible))
            return;

        if (this._tooltipTimeoutId)
            GLib.Source.remove(this._tooltipTimeoutId);
        const delay = this._appTooltip?.visible ? 0 : APP_TOOLTIP_DELAY;
        this._setTooltipItem(item);
        this._tooltipTimeoutId = GLib.timeout_add(
            GLib.PRIORITY_DEFAULT,
            delay,
            () => {
                this._tooltipTimeoutId = 0;
                if (this._tooltipItem === item && item.mapped)
                    this._showTooltip(item);
                return GLib.SOURCE_REMOVE;
            }
        );
    }

    hideTooltip(animate = true) {
        this._clearTimeout('_tooltipTimeoutId');
        this._clearTimeout('_tooltipCloseId');
        this._hideTooltip(animate);
    }

    scheduleTooltipClose() {
        if (!this._tooltipItem)
            return;
        if (!this._appTooltip?.visible) {
            this.hideTooltip();
            return;
        }
        if (this._tooltipCloseId)
            return;

        this._tooltipCloseId = GLib.timeout_add(
            GLib.PRIORITY_DEFAULT,
            APP_TOOLTIP_CLOSE_DELAY,
            () => {
                if (!this.isPointerInMagnifyBounds() ||
                    this._taskbarItemAtPointer() !== this._tooltipItem) {
                    this._tooltipCloseId = 0;
                    this.hideTooltip();
                    return GLib.SOURCE_REMOVE;
                }

                return GLib.SOURCE_CONTINUE;
            }
        );
    }

    isPointerInMagnifyBounds() {
        return this._isPointerInMagnifyBounds();
    }

    _setTrackedItem(name, destroyName, item, onDestroy) {
        if (this[name] === item)
            return;

        if (this[destroyName]) {
            this[name].disconnect(this[destroyName]);
            this[destroyName] = 0;
        }
        this[name] = item;
        if (item) {
            this[destroyName] = item.connect('destroy', () => {
                this[destroyName] = 0;
                onDestroy();
            });
        }
    }

    _setPreviewItem(item) {
        this._setTrackedItem(
            '_previewItem',
            '_previewItemDestroyId',
            item,
            () => this.hide()
        );
    }

    _setPreviewSwitchItem(item) {
        this._setTrackedItem(
            '_previewSwitchItem',
            '_previewSwitchItemDestroyId',
            item,
            () => this._clearSwitch()
        );
    }

    _setTooltipItem(item) {
        this._setTrackedItem(
            '_tooltipItem',
            '_tooltipItemDestroyId',
            item,
            () => this.hideTooltip(false)
        );
    }

    _hideTooltip(animate) {
        this._setTooltipItem(null);

        const label = this._appTooltip;
        if (!label?.visible)
            return;

        label.remove_all_transitions();
        if (!animate) {
            label.hide();
            return;
        }

        label.ease({
            opacity: 0,
            duration: APP_TOOLTIP_HIDE_TIME,
            mode: Clutter.AnimationMode.EASE_OUT_QUAD,
            onComplete: () => {
                if (!this._tooltipItem)
                    label.hide();
            },
        });
    }

    show(item) {
        this._clearTimeouts();
        this.hideTooltip();
        if (this._overviewIsVisible()) {
            this.hide();
            return;
        }
        const windows = this._windowsForItem(item)
            .sort((a, b) => b.get_user_time() - a.get_user_time());
        if (windows.length === 0)
            return;

        if (this._previewItem === item &&
            item._taskbarButton._taskbarPreviewMenu?.isOpen)
            return;

        this.hide();

        const button = item._taskbarButton;
        const monitor = Main.layoutManager.findMonitorForActor(item) ??
            Main.layoutManager.primaryMonitor;
        const menu = new PopupMenu.PopupMenu(
            button,
            0.5,
            panelArrowSide(this._settings)
        );
        const themeClass = panelUsesLightTheme(this._settings)
            ? 'simple-taskbar-preview-light'
            : 'simple-taskbar-preview-dark';
        menu.actor.add_style_class_name('simple-taskbar-preview-menu');
        menu.actor.add_style_class_name(themeClass);
        menu.box.add_style_class_name(
            'simple-taskbar-preview-popup-content'
        );
        const section = new PopupMenu.PopupMenuSection();
        const previewBox = new St.BoxLayout({
            style_class: 'simple-taskbar-preview-list',
        });
        const viewport = new St.Viewport({
            layout_manager: new Clutter.BinLayout(),
        });
        viewport.add_child(previewBox);
        const scrollView = new St.ScrollView({
            style_class: 'simple-taskbar-preview-scroll',
            style: `max-width: ${Math.max(320, monitor.width - 32)}px;`,
            hscrollbar_policy: St.PolicyType.AUTOMATIC,
            vscrollbar_policy: St.PolicyType.AUTOMATIC,
            enable_mouse_scrolling: true,
            overlay_scrollbars: false,
            child: viewport,
        });
        const scrollPreviews = event => {
            const adjustment = scrollView.hadjustment;
            const increment = Math.max(
                adjustment.step_increment,
                PREVIEW_WIDTH / 2
            );
            const delta = getScrollDelta(event, increment);

            adjustment.set_value(adjustment.get_value() + delta);
            return Clutter.EVENT_STOP;
        };
        for (const window of windows) {
            const preview = this._createWindowPreview(window);
            if (preview)
                previewBox.add_child(preview);
        }
        if (previewBox.get_n_children() === 0) {
            menu.destroy();
            return;
        }

        section.actor.add_child(scrollView);
        menu.addMenuItem(section);
        // Window previews are visual flyouts rather than modal menus, so they
        // must not consume the first click intended for the source icon.
        menu.actor.track_hover = true;
        menu.actor.hide();
        Main.uiGroup.add_child(menu.actor);
        button._taskbarPreviewMenu = menu;
        button._taskbarPreviewBox = previewBox;
        this._setPreviewItem(item);
        this._setHoverItem(item);

        menu.actor.connect('notify::hover', actor => {
            if (this._previewItem !== item)
                return;
            if (actor.hover)
                this._clearTimeout('_previewCloseId');
            else {
                this._restorePeek();
                if (!item.hover && !pointerButtonIsPressed())
                    this.scheduleClose();
            }
        });
        menu.actor.connect('captured-event', (_actor, event) => {
            if (this._previewItem !== item)
                return Clutter.EVENT_PROPAGATE;

            if (event.type() === Clutter.EventType.SCROLL)
                return scrollPreviews(event);
            if (event.type() !== Clutter.EventType.MOTION)
                return Clutter.EVENT_PROPAGATE;
            if (pointerButtonIsPressed())
                return Clutter.EVENT_PROPAGATE;

            const hoveredItem = this._taskbarItemAtPointer();
            const pointerInsidePreview = this._pointerIsOverPreview(item);
            if (hoveredItem)
                this._setHoverItem(hoveredItem);
            else if (!pointerInsidePreview)
                this._setHoverItem(null);

            if (hoveredItem && hoveredItem !== item &&
                this._windowsForItem(hoveredItem).length > 0) {
                this.scheduleSwitch(hoveredItem);
                return Clutter.EVENT_PROPAGATE;
            }

            if (this._previewSwitchId)
                this._clearSwitch();

            if (pointerInsidePreview)
                this._clearTimeout('_previewCloseId');
            else
                this.scheduleClose();

            return Clutter.EVENT_PROPAGATE;
        });
        menu.connect('open-state-changed', (_popup, isOpen) => {
            if (!isOpen && this._previewItem === item)
                this.scheduleClose();
        });

        openPopupMenu(menu);
        this._positionPreviewAboveMagnification(menu);
    }

    hide(animate = false) {
        this._clearTimeouts();
        this._hidePreview(animate);
    }

    _hidePreview(animate) {
        this._restorePeek();
        this._releaseHoverItem();
        const item = this._previewItem;
        this._setPreviewItem(null);
        if (!item)
            return;

        const button = item._taskbarButton;
        const menu = button._taskbarPreviewMenu;
        button._taskbarPreviewMenu = null;
        button._taskbarPreviewBox = null;
        if (!menu)
            return;

        if (!animate || !menu.isOpen) {
            menu.destroy();
            return;
        }

        this._closingPreviewMenus.add(menu);
        menu.connect('menu-closed', () => {
            if (this._closingPreviewMenus.delete(menu))
                menu.destroy();
        });
        closePopupMenu(menu);
    }

    _positionPreviewAboveMagnification(menu) {
        const outward = this._getHoverAnimationOutwardReserve();
        if (!outward)
            return;

        const position = panelPosition(this._settings);
        const property = position === 'top' || position === 'bottom'
            ? 'translation_y'
            : 'translation_x';
        const direction = position === 'top' || position === 'left'
            ? 1
            : -1;
        menu.actor.remove_transition(property);
        menu.actor[property] = direction * outward;
    }

    _interestingWindows(app) {
        return this._getInterestingWindows(app);
    }

    _overviewIsVisible() {
        return Main.overview.visible || Main.overview.visibleTarget;
    }

    _windowsForItem(item) {
        return windowsForTaskbarItem(
            item,
            app => this._interestingWindows(app)
        );
    }

    _clearTimeout(name) {
        const id = this[name];
        if (id)
            GLib.Source.remove(id);
        this[name] = 0;
        if (name === '_previewOpenId')
            this._previewPendingItem = null;
    }

    _schedulePeek(window, preview) {
        this._clearTimeout('_peekTimeoutId');
        if (!this._settings.get_boolean('peek-mode'))
            return;
        if (this._peekedWindow === window)
            return;

        this._peekTimeoutId = GLib.timeout_add(
            GLib.PRIORITY_DEFAULT,
            this._settings.get_int('enter-peek-mode-timeout'),
            () => {
                this._peekTimeoutId = 0;
                if (preview.hover)
                    this._peekWindow(window);
                return GLib.SOURCE_REMOVE;
            }
        );
    }

    _peekWindow(window) {
        if (!this._previewItem)
            return;

        if (this._peekedWindow === window)
            return;

        const currentWorkspace =
            global.workspace_manager.get_active_workspace();

        if (Main.sessionMode.hasWorkspaces &&
            window.get_workspace() !== currentWorkspace)
            return;

        this._restorePeekedWindowStack();
        this._peekedWindow = window;
        this._focusMetaWindow(
            this._settings.get_int('peek-mode-opacity'),
            window
        );
    }

    _focusMetaWindow(dimOpacity, window, ignoreFocus = false) {
        const isAppSpread = !Main.sessionMode.hasWorkspaces;
        const currentWorkspace =
            global.workspace_manager.get_active_workspace();
        const windows = isAppSpread
            ? global.get_window_actors().map(actor => actor.meta_window)
            : currentWorkspace.list_windows();

        for (const metaWindow of windows) {
            const windowActor = metaWindow.get_compositor_private();
            const isFocused = !ignoreFocus && metaWindow === window;
            if (!windowActor)
                continue;

            if (isFocused) {
                const parent = windowActor.get_parent();
                this._peekedWindowStack = {
                    parent,
                    index: parent.get_children().indexOf(windowActor),
                };
                parent.set_child_above_sibling(windowActor, null);
            }

            if (isFocused && metaWindow.minimized)
                windowActor.show();

            this._animateWindowOpacity(
                metaWindow,
                windowActor,
                isFocused ? 255 : dimOpacity
            );
        }
    }

    _animateWindowOpacity(metaWindow, windowActor, opacity) {
        if (metaWindow.minimized)
            return;

        const visible = opacity > 0;
        const visual = windowActor.get_first_child() || windowActor;
        const initialOpacity = visual.opacity;
        let targetOpacity = opacity;

        if (!windowActor.visible && visible) {
            visual.opacity = 0;
            windowActor.visible = visible;
            targetOpacity = Math.min(initialOpacity, targetOpacity);
        }

        const options = {
            opacity: targetOpacity,
            duration: PREVIEW_PEEK_DURATION,
            mode: Clutter.AnimationMode.EASE_IN_OUT_QUAD,
        };
        if (!visible) {
            options.onComplete = () => {
                windowActor.visible = visible;
                visual.opacity = initialOpacity;
            };
        }

        visual.ease(options);
    }

    _restorePeekedWindowStack() {
        if (!this._peekedWindow)
            return;

        const windowActor = this._peekedWindow.get_compositor_private();
        if (windowActor && this._peekedWindowStack) {
            windowActor.get_parent().set_child_at_index(
                windowActor,
                this._peekedWindowStack.index
            );
            if (this._peekedWindow.minimized)
                windowActor.hide();
        }
        this._peekedWindowStack = null;
    }

    _restorePeek() {
        if (!this._peekedWindow)
            return;

        this._restorePeekedWindowStack();
        this._focusMetaWindow(255, this._peekedWindow, true);
        this._peekedWindow = null;
    }

    _clearTimeouts() {
        this._clearTimeout('_previewOpenId');
        this._clearTimeout('_previewCloseId');
        this._clearTimeout('_peekTimeoutId');
        this._clearSwitch();
        if (this._previewRefreshId)
            GLib.Source.remove(this._previewRefreshId);
        this._previewRefreshId = 0;
    }

    _clearSwitch() {
        if (this._previewSwitchId)
            GLib.Source.remove(this._previewSwitchId);
        this._previewSwitchId = 0;
        this._setPreviewSwitchItem(null);
    }

    _pointerIsOverPreview(item) {
        if (!item.mapped)
            return false;

        const [x, y] = global.get_pointer();
        const actor = global.stage.get_actor_at_pos(Clutter.PickMode.ALL, x, y);
        const menuActor = item._taskbarButton._taskbarPreviewMenu?.actor;
        return item.contains(actor) || menuActor?.contains(actor) === true;
    }

    _taskbarItemAtPointer() {
        const [x, y] = global.get_pointer();
        const actor = global.stage.get_actor_at_pos(Clutter.PickMode.ALL, x, y);

        for (const item of this._getTaskbarItems()) {
            if (item.mapped && item.contains(actor))
                return item;
        }

        return null;
    }

    _setHoverItem(item) {
        if (this._previewHoverItem === item)
            return;

        this._previewHoverItem?.remove_style_pseudo_class('hover');
        this._previewHoverItem = item;
        item?.add_style_pseudo_class('hover');

        if (item && this._windowsForItem(item).length === 0)
            this.scheduleTooltip(item);
        else
            this.hideTooltip();
    }

    raiseOverlays() {
        const menuActor =
            this._previewItem?._taskbarButton._taskbarPreviewMenu?.actor;
        if (menuActor)
            Main.uiGroup.set_child_above_sibling(menuActor, null);
        if (this._appTooltip)
            Main.uiGroup.set_child_above_sibling(this._appTooltip, null);
    }

    _releaseHoverItem() {
        const item = this._previewHoverItem;
        this._previewHoverItem = null;
        if (item && item !== this._taskbarItemAtPointer())
            item.remove_style_pseudo_class('hover');
    }

    _showTooltip(item) {
        if (!this._appTooltip) {
            this._appTooltip = new St.Label({style_class: 'dash-label'});
            this._appTooltip.hide();
            Main.layoutManager.addChrome(this._appTooltip);
        }

        const label = this._appTooltip;
        this.raiseOverlays();
        label.remove_all_transitions();
        label.set_text(item._taskbarApp.get_name());
        label.opacity = 0;
        label.show();

        const [stageX, stageY] = item.get_transformed_position();
        const [, labelWidth] = label.get_preferred_width(-1);
        const [, labelHeight] = label.get_preferred_height(labelWidth);
        const monitor = Main.layoutManager.findMonitorForActor(item) ??
            Main.layoutManager.primaryMonitor;
        const itemWidth = item.allocation.get_width();
        const itemHeight = item.allocation.get_height();
        const position = panelPosition(this._settings);
        const outward = this._getHoverAnimationOutwardReserve();
        let x;
        let y;
        if (positionIsVertical(position)) {
            x = position === 'left'
                ? Math.min(
                    monitor.x + monitor.width - labelWidth,
                    stageX + itemWidth + 8 + outward
                )
                : Math.max(monitor.x, stageX - labelWidth - 8 - outward);
            y = Math.clamp(
                stageY + Math.floor((itemHeight - labelHeight) / 2),
                monitor.y,
                monitor.y + monitor.height - labelHeight
            );
        } else {
            x = Math.clamp(
                stageX + Math.floor((itemWidth - labelWidth) / 2),
                monitor.x,
                monitor.x + monitor.width - labelWidth
            );
            y = panelIsTop(this._settings)
                ? Math.min(
                    monitor.y + monitor.height - labelHeight,
                    stageY + itemHeight + 8 + outward
                )
                : Math.max(monitor.y, stageY - labelHeight - 8 - outward);
        }
        label.set_position(x, y);
        label.ease({
            opacity: 255,
            duration: APP_TOOLTIP_SHOW_TIME,
            mode: Clutter.AnimationMode.EASE_OUT_QUAD,
        });
    }

    _queueRefresh(app) {
        if (this._previewRefreshId)
            return;

        this._previewRefreshId = GLib.idle_add(GLib.PRIORITY_HIGH_IDLE, () => {
            this._previewRefreshId = 0;
            const item = this._previewItem;
            if (item?._taskbarApp === app)
                this._refresh(item);
            return GLib.SOURCE_REMOVE;
        });
    }

    _refresh(item) {
        const button = item._taskbarButton;
        const previewBox = button._taskbarPreviewBox;
        const windows = this._windowsForItem(item)
            .sort((a, b) => b.get_user_time() - a.get_user_time());
        if (!previewBox || windows.length === 0) {
            this.hide(true);
            return;
        }

        this._clearTimeout('_peekTimeoutId');
        this._restorePeek();
        previewBox.destroy_all_children();
        for (const window of windows) {
            const preview = this._createWindowPreview(window);
            if (preview)
                previewBox.add_child(preview);
        }
        button._taskbarPreviewMenu.actor.queue_relayout();
    }

    _createWindowPreview(window) {
        const source = window.get_compositor_private();
        if (!source)
            return null;

        const [sourceWidth, sourceHeight] = source.get_size();
        if (sourceWidth <= 0 || sourceHeight <= 0)
            return null;

        const scale = Math.min(
            1,
            PREVIEW_WIDTH / sourceWidth,
            PREVIEW_HEIGHT / sourceHeight
        );
        const previewWidth = Math.max(1, Math.round(sourceWidth * scale));
        const previewHeight = Math.max(1, Math.round(sourceHeight * scale));
        const clone = new Clutter.Clone({
            source,
            width: previewWidth,
            height: previewHeight,
            x_align: Clutter.ActorAlign.CENTER,
            y_align: Clutter.ActorAlign.CENTER,
            x_expand: true,
            y_expand: true,
        });
        const thumbnail = new St.Widget({
            style_class: 'simple-taskbar-preview-thumbnail',
            layout_manager: new Clutter.BinLayout(),
            width: previewWidth,
            height: previewHeight,
            clip_to_allocation: true,
        });
        thumbnail.add_child(clone);

        const title = window.get_title() || _('Untitled Window');
        const label = new St.Label({
            style_class: 'simple-taskbar-preview-title',
            text: title,
            width: previewWidth,
            x_align: Clutter.ActorAlign.START,
        });
        label.clutter_text.ellipsize = Pango.EllipsizeMode.END;
        const content = new St.BoxLayout({
            style_class: 'simple-taskbar-preview-content',
            orientation: Clutter.Orientation.VERTICAL,
        });
        content.add_child(label);
        content.add_child(thumbnail);

        const previewButton = new St.Button({
            style_class: 'simple-taskbar-preview-button',
            reactive: true,
            can_focus: true,
            track_hover: true,
            accessible_name: title,
            child: content,
        });
        previewButton.connect('button-press-event', (_actor, event) => {
            if (event.get_button() !== Clutter.BUTTON_MIDDLE ||
                !this._settings.get_boolean('preview-middle-click-close') ||
                !window.can_close())
                return Clutter.EVENT_PROPAGATE;

            this.hide();
            window.delete(global.get_current_time());
            return Clutter.EVENT_STOP;
        });
        previewButton.connect('clicked', () => {
            this.hide();
            this._onPreviewActivated();
            Main.activateWindow(window);
            Main.overview.hide();
        });

        const preview = new St.Widget({
            style_class: 'simple-taskbar-preview-item',
            layout_manager: new Clutter.BinLayout(),
            reactive: true,
            track_hover: true,
        });
        preview.add_child(previewButton);
        preview.connect('notify::hover', actor => {
            if (actor.hover)
                this._schedulePeek(window, actor);
            else {
                this._clearTimeout('_peekTimeoutId');
                this._restorePeek();
            }
        });

        if (window.can_close()) {
            const closeButton = new St.Button({
                style_class: 'simple-taskbar-preview-close',
                reactive: true,
                can_focus: true,
                track_hover: true,
                accessible_name: _('Close Window'),
                child: new St.Icon({
                    style_class: 'simple-taskbar-preview-close-icon',
                    icon_name: 'window-close-symbolic',
                }),
            });
            const closeButtonBin = new St.Widget({
                layout_manager: new Clutter.BinLayout(),
                opacity: 0,
                x_align: Clutter.ActorAlign.END,
                y_align: Clutter.ActorAlign.START,
                x_expand: true,
                y_expand: true,
            });
            const setCloseButtonVisible = visible => {
                closeButtonBin.remove_all_transitions();
                closeButtonBin.ease({
                    opacity: visible ? 255 : 0,
                    duration: 100,
                    mode: Clutter.AnimationMode.EASE_OUT_QUAD,
                });
            };

            closeButtonBin.add_child(closeButton);
            closeButton.connect('clicked', () => {
                setCloseButtonVisible(false);
                window.delete(global.get_current_time());
            });
            closeButton.connect('key-focus-in', () => {
                setCloseButtonVisible(true);
            });
            closeButton.connect('key-focus-out', () => {
                if (!preview.hover)
                    setCloseButtonVisible(false);
            });
            preview.connect('notify::hover', actor => {
                setCloseButtonVisible(actor.hover);
            });
            preview.add_child(closeButtonBin);
        }

        return preview;
    }
}
