// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (C) 2026 sultech

import Adw from 'gi://Adw';
import Gtk from 'gi://Gtk';

import {
    ExtensionPreferences,
    gettext as _,
} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

import {
    addPanelModeGroup,
    connectDefaultGnomePanelSync,
} from './src/prefs/panelModeGroup.js';
import {addApplicationIconsGroup} from './src/prefs/applicationIconsGroup.js';
import {addDockAppearanceGroup} from './src/prefs/dockAppearanceGroup.js';
import {addDockBehaviorGroup} from './src/prefs/dockBehaviorGroup.js';
import {addTaskbarBehaviorGroup} from './src/prefs/taskbarBehaviorGroup.js';
import {createBlurMyShellState} from './src/prefs/blurMyShellState.js';
import {addPanelAppearancePage} from './src/prefs/panelAppearancePage.js';
import {addPanelItemsPage} from './src/prefs/panelItemsPage.js';
import {addDockItemsPage} from './src/prefs/dockItemsPage.js';
import {addLocationsGroup} from './src/prefs/locationsGroup.js';
import {addStartMenuPage} from './src/prefs/startMenuPage.js';
import {SettingsSignalTracker} from './src/prefs/settingsSignalTracker.js';
import {addWindowSwitchingPage} from './src/prefs/windowSwitchingPage.js';
import {addAboutPage} from './src/prefs/aboutPage.js';
export default class SimpleTaskbarPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        Gtk.IconTheme.get_for_display(window.get_display()).add_search_path(
            `${this.path}/icons/scalable/actions`
        );
        window.set_default_size(640, 740);
        window._settings = this.getSettings();
        const settingsSignalTracker = new SettingsSignalTracker();
        window.connect('close-request', () => settingsSignalTracker.destroy());
        const connectSettings = (settings, signal, callback) =>
            settingsSignalTracker.connect(settings, signal, callback);
        const blurMyShell = createBlurMyShellState(connectSettings);
        const blurMyShellPanelBlurEnabled =
            blurMyShell.blurMyShellPanelBlurEnabled;
        const blurMyShellPopupBlurEnabled =
            blurMyShell.blurMyShellPopupBlurEnabled;
        const panelPositions = [
            {value: 'left', label: _('Left')},
            {value: 'center', label: _('Center')},
            {value: 'right', label: _('Right')},
        ];

        const page = new Adw.PreferencesPage({
            title: _('Taskbar'),
            icon_name: 'preferences-desktop-appearance-symbolic',
        });
        window.add(page);

        const dockPage = new Adw.PreferencesPage({
            title: _('Dock'),
            icon_name: 'simple-taskbar-dock-symbolic',
        });
        window.add(dockPage);

        const startMenuPage = new Adw.PreferencesPage({
            title: _('Start Menu'),
            icon_name: 'view-app-grid-symbolic',
        });
        window.add(startMenuPage);

        addWindowSwitchingPage(
            window,
            window._settings,
            connectSettings
        );

        const startMenu = addStartMenuPage({
            window,
            page: startMenuPage,
            taskbarPage: page,
            dockPage,
            settings: window._settings,
            extensionPath: this.path,
            panelPositions,
            blurMyShellPanelBlurEnabled,
            blurMyShellPopupBlurEnabled,
            connectSettings,
        });
        const followAppAlignmentSwitch =
            startMenu.followAppAlignmentSwitch;
        const windowsStartMenuSwitch =
            startMenu.windowsStartMenuSwitch;
        blurMyShell.setStartMenuSync(startMenu.syncTransparency);

        const panelMode = addPanelModeGroup({
            page,
            dockPage,
            settings: window._settings,
            createSettings: () => this.getSettings(),
            connectSettings,
        });
        const taskbarModeRow = panelMode.taskbarModeRow;
        const taskbarModeSwitch = panelMode.taskbarModeSwitch;
        const taskbarOverviewButton = panelMode.taskbarOverviewButton;
        const defaultGnomePanelRow = panelMode.defaultGnomePanelRow;
        const defaultGnomePanelSwitch = panelMode.defaultGnomePanelSwitch;
        const defaultGnomePanelOverviewButton =
            panelMode.defaultGnomePanelOverviewButton;
        const windowsXpOverviewButton = panelMode.windowsXpOverviewButton;
        const dockModeRow = panelMode.dockModeRow;
        const dockModeSwitch = panelMode.dockModeSwitch;
        const dockOverviewButton = panelMode.dockOverviewButton;
        const dockModeGroup = panelMode.dockModeGroup;
        const dockPositionRow = panelMode.dockPositionRow;
        const dockMaxLengthRow = panelMode.dockMaxLengthRow;
        const dockPanelModeSwitch = panelMode.dockPanelModeSwitch;
        const windowsXpThemeSwitch = panelMode.windowsXpThemeSwitch;

        const icons = addApplicationIconsGroup({
            page,
            dockPage,
            settings: window._settings,
            connectSettings,
            panelPositions,
        });
        const appearanceGroup = icons.appearanceGroup;
        const iconSizeRow = icons.iconSizeRow;
        const iconSpacingRow = icons.iconSpacingRow;
        const iconEdgePaddingRow = icons.iconEdgePaddingRow;
        const appAlignmentRow = icons.appAlignmentRow;
        const combineAppButtonsRow = icons.combineAppButtonsRow;
        const syncLabelSensitivity = icons.syncLabelSensitivity;
        const applicationOverflowSwitch =
            icons.applicationOverflowSwitch;
        const isolateMonitorsSwitch = icons.isolateMonitorsSwitch;

        const dockAppearance = addDockAppearanceGroup({
            page: dockPage,
            settings: window._settings,
            connectSettings,
            blurMyShellPanelBlurEnabled,
            dockModeGroup,
            dockPositionRow,
            dockMaxLengthRow,
        });
        blurMyShell.setDockPanelSyncs(
            dockAppearance.syncTransparency,
            dockAppearance.syncCustomColor
        );
        addDockBehaviorGroup({
            page: dockPage,
            settings: window._settings,
            connectSettings,
        });

        connectDefaultGnomePanelSync({
            settings: window._settings,
            createSettings: () => this.getSettings(),
            connectSettings,
            taskbarModeRow,
            taskbarModeSwitch,
            taskbarOverviewButton,
            defaultGnomePanelRow,
            defaultGnomePanelSwitch,
            defaultGnomePanelOverviewButton,
            windowsXpOverviewButton,
            dockModeSwitch,
            dockOverviewButton,
            dockPositionRow,
            dockMaxLengthRow,
            dockPanelModeSwitch,
            appearanceGroup,
            startMenuPage,
        });

        const panelAppearance = addPanelAppearancePage({
            page,
            settings: window._settings,
            connectSettings,
            createSettings: () => this.getSettings(),
            blurMyShellPanelBlurEnabled,
            windowsXpThemeSwitch,
            taskbarModeRow,
            iconSizeRow,
            iconSpacingRow,
            iconEdgePaddingRow,
            defaultGnomePanelRow,
            dockModeRow,
            dockPositionRow,
            dockMaxLengthRow,
            dockPanelModeSwitch,
            appAlignmentRow,
            combineAppButtonsRow,
            syncLabelSensitivity,
        });
        blurMyShell.setPanelSyncs(
            panelAppearance.syncTransparency,
            panelAppearance.syncCustomColor
        );

        addTaskbarBehaviorGroup({
            page,
            settings: window._settings,
            connectSettings,
            isolateMonitorsSwitch,
        });

        addPanelItemsPage({
            window,
            settings: window._settings,
            connectSettings,
            page,
            panelPositions,
            windowsStartMenuSwitch,
            followAppAlignmentSwitch,
        });

        addDockItemsPage({
            page: dockPage,
            settings: window._settings,
            connectSettings,
            panelPositions,
        });

        addLocationsGroup({
            page,
            dockPage,
            settings: window._settings,
            connectSettings,
        });

        addAboutPage(
            window,
            this.path,
            window._settings,
            () => this.getSettings()
        );
    }
}
