// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (C) 2026 sultech

import Adw from 'gi://Adw';
import Gio from 'gi://Gio';

import {gettext as _} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

import {
    MAX_PANEL_HEIGHT,
    MIN_PANEL_HEIGHT,
    standardMinimumPanelHeight,
} from '../shared/panelSizing.js';
import {
    applyWindowsXpThemeSettings,
    WINDOWS_XP_ICON_SPACING,
} from '../shared/windowsXpTheme.js';
import {
    PANEL_MODE_WINDOWS_XP,
    restorePanelModeAfterWindowsXp,
    setPanelMode,
    setPanelPosition,
} from '../shared/panelModeProfiles.js';
import {
    addColorRow,
    addComboRow,
    addSpinRow,
    addSwitchRow,
} from './preferencesWidgets.js';
import {
    createDynamicTransparencyOptionsButton,
} from './dynamicTransparencyDialog.js';
import {createPanelThicknessSizing} from './panelThicknessSizing.js';

const PANEL_HEIGHT_FOLLOW_KEY = 'panel-height-follow-icon-size';

export function addPanelAppearancePage({
    page,
    settings,
    connectSettings,
    createSettings,
    blurMyShellPanelBlurEnabled,
    windowsXpThemeSwitch,
    taskbarModeRow,
    iconSizeRow,
    iconSpacingRow,
    iconEdgePaddingRow,
    defaultGnomePanelRow,
    dockModeRow,
    dockPositionRow,
    dockMaxLengthRow,
    dockPanelModeSwitch,
    appAlignmentRow,
    combineAppButtonsRow,
    syncLabelSensitivity,
}) {
    const panelAppearanceGroup = new Adw.PreferencesGroup({
        title: _('Taskbar Appearance'),
        description: _('Change the taskbar height, colour scheme, and transparency.'),
    });
    page.add(panelAppearanceGroup);

    const {
        followSwitch: panelHeightFollowSwitch,
        followsIcons: panelHeightFollowsIcons,
    } = createPanelThicknessSizing(settings, connectSettings, {
        heightKey: 'panel-height',
        followKey: PANEL_HEIGHT_FOLLOW_KEY,
        followSubtitle: _('Keep the taskbar only as thick as its icons need'),
        isActive: () => !settings.get_boolean('default-gnome-panel') &&
            !settings.get_boolean('windows-xp-theme-enabled'),
    });
    panelAppearanceGroup.add(panelHeightFollowSwitch);

    const panelHeightRow = addSpinRow(
        panelAppearanceGroup,
        settings,
        {
            key: 'panel-height',
            title: _('Taskbar Thickness'),
            subtitle: _(
                'Oversized icons shrink automatically when the taskbar is reduced'
            ),
            lower: MIN_PANEL_HEIGHT,
            upper: MAX_PANEL_HEIGHT,
        },
        connectSettings
    );
    const panelPositionRow = addComboRow(
        panelAppearanceGroup,
        settings,
        {
            key: 'panel-position',
            title: _('Taskbar Position'),
            subtitle: _(
                'Place the taskbar at a screen edge'
            ),
            choices: [
                {value: 'top', label: _('Top')},
                {value: 'bottom', label: _('Bottom')},
                {value: 'left', label: _('Left')},
                {value: 'right', label: _('Right')},
            ],
            setValue: position => {
                const settings = createSettings();
                settings.delay();
                setPanelPosition(settings, position);
                settings.apply();
            },
        },
        connectSettings
    );

    let syncingWindowsXpTheme = false;
    const syncWindowsXpTheme = () => {
        const enabled = settings.get_boolean(
            'windows-xp-theme-enabled'
        );
        if (enabled) {
            if (settings.get_boolean('default-gnome-panel')) {
                settings.set_boolean(
                    'default-gnome-panel',
                    false
                );
            }
            applyWindowsXpThemeSettings(settings);
        }
        syncingWindowsXpTheme = true;
        windowsXpThemeSwitch.active = enabled;
        panelHeightRow.get_adjustment().set_lower(
            enabled || settings.get_boolean('default-gnome-panel')
                ? MIN_PANEL_HEIGHT
                : standardMinimumPanelHeight(settings)
        );
        iconSpacingRow.get_adjustment().set_lower(
            enabled ? WINDOWS_XP_ICON_SPACING : 0
        );
        const iconSpacing = settings.get_int('icon-spacing');
        if (iconSpacingRow.get_value() !== iconSpacing)
            iconSpacingRow.set_value(iconSpacing);
        iconSizeRow.sensitive = !enabled;
        iconSpacingRow.sensitive = !enabled;
        iconEdgePaddingRow.sensitive = !enabled;
        panelHeightFollowSwitch.sensitive = !enabled &&
            !settings.get_boolean('default-gnome-panel');
        panelHeightRow.sensitive = !enabled && !panelHeightFollowsIcons();
        panelPositionRow.sensitive = !enabled;
        taskbarModeRow.sensitive = true;
        defaultGnomePanelRow.sensitive =
            !settings.get_boolean('dock-mode');
        dockModeRow.sensitive = true;
        dockPositionRow.sensitive = !enabled &&
            settings.get_boolean('dock-mode');
        dockPanelModeSwitch.sensitive = !enabled &&
            settings.get_boolean('dock-mode');
        dockMaxLengthRow.sensitive = !enabled &&
            settings.get_boolean('dock-mode') &&
            !dockPanelModeSwitch.active;
        appAlignmentRow.sensitive = !enabled &&
            (!settings.get_boolean('dock-mode') ||
                settings.get_boolean('dock-panel-mode'));
        combineAppButtonsRow.sensitive = true;
        syncLabelSensitivity();
        syncingWindowsXpTheme = false;
    };
    const setWindowsXpTheme = enabled => {
        const settings = createSettings();
        settings.delay();
        if (enabled)
            setPanelMode(settings, PANEL_MODE_WINDOWS_XP);
        else
            restorePanelModeAfterWindowsXp(settings);
        settings.apply();
    };
    windowsXpThemeSwitch.connect('notify::active', () => {
        if (syncingWindowsXpTheme)
            return;

        const enabled = windowsXpThemeSwitch.active;
        if (enabled === settings.get_boolean(
            'windows-xp-theme-enabled'
        )) {
            return;
        }
        setWindowsXpTheme(enabled);
        syncWindowsXpTheme();
    });
    connectSettings(
        settings,
        'changed::windows-xp-theme-enabled',
        syncWindowsXpTheme
    );
    connectSettings(settings, 'changed::dock-mode', syncWindowsXpTheme);
    connectSettings(
        settings,
        'changed::default-gnome-panel',
        syncWindowsXpTheme
    );
    connectSettings(
        settings,
        'changed::dock-panel-mode',
        syncWindowsXpTheme
    );
    connectSettings(settings, 'changed::icon-size', syncWindowsXpTheme);
    connectSettings(settings, 'changed::icon-spacing', syncWindowsXpTheme);
    connectSettings(
        settings,
        'changed::icon-edge-padding',
        syncWindowsXpTheme
    );
    connectSettings(settings, 'changed::panel-height', syncWindowsXpTheme);
    connectSettings(
        settings,
        `changed::${PANEL_HEIGHT_FOLLOW_KEY}`,
        syncWindowsXpTheme
    );
    connectSettings(settings, 'changed::panel-position', syncWindowsXpTheme);
    connectSettings(
        settings,
        'changed::panel-button-padding',
        syncWindowsXpTheme
    );
    connectSettings(
        settings,
        'changed::custom-indicator-colors-enabled',
        syncWindowsXpTheme
    );
    connectSettings(
        settings,
        'changed::custom-panel-color-enabled',
        syncWindowsXpTheme
    );
    connectSettings(
        settings,
        'changed::activities-button-position',
        syncWindowsXpTheme
    );
    connectSettings(settings, 'changed::app-alignment', syncWindowsXpTheme);
    connectSettings(
        settings,
        'changed::start-button-position',
        syncWindowsXpTheme
    );
    connectSettings(
        settings,
        'changed::use-pinned-apps-as-launchers',
        syncWindowsXpTheme
    );
    connectSettings(
        settings,
        'changed::combine-app-buttons-mode',
        syncWindowsXpTheme
    );
    connectSettings(
        settings,
        'changed::hide-app-labels',
        syncWindowsXpTheme
    );
    syncWindowsXpTheme();

    const themeRow = new Adw.ExpanderRow({
        title: _('Theme and Styling'),
        subtitle: _(
            'Choose the taskbar theme, colours, gradient, and text appearance'
        ),
    });
    panelAppearanceGroup.add(themeRow);

    const followSystemThemeSwitch = new Adw.SwitchRow({
        title: _('Follow System Theme'),
        subtitle: _('Match the active GNOME Shell theme, independently of application colours'),
        active: settings.get_boolean('panel-theme-follow-system'),
    });
    themeRow.add_row(followSystemThemeSwitch);
    settings.bind(
        'panel-theme-follow-system',
        followSystemThemeSwitch,
        'active',
        Gio.SettingsBindFlags.DEFAULT
    );

    const panelThemeRow = addComboRow(
        themeRow,
        settings,
        {
            key: 'panel-theme',
            title: _('Taskbar Theme'),
            subtitle: _('Choose the colour scheme when system matching is off'),
            choices: [
                {value: 'light', label: _('Light')},
                {value: 'dark', label: _('Dark')},
            ],
            addRow: row => themeRow.add_row(row),
        },
        connectSettings
    );
    followSystemThemeSwitch.connect('notify::active', widget => {
        syncPanelThemeControls();
        if (widget.active)
            settings.set_boolean(
                'custom-panel-color-enabled',
                false
            );
    });

    const transparencySwitchSubtitle = _(
        'Make the taskbar background transparent'
    );
    const dynamicTransparencySubtitle = _(
        'Adjust transparency according to the selected window state'
    );
    const panelBlurTransparencySubtitle = _(
        'Disable Blur My Shell panel blur to use this option'
    );
    const transparencyExpander = new Adw.ExpanderRow({
        title: _('Transparency'),
        subtitle: _('Control the taskbar background transparency'),
    });
    panelAppearanceGroup.add(transparencyExpander);

    const transparencySwitch = new Adw.SwitchRow({
        title: _('Enable Transparency'),
        subtitle: transparencySwitchSubtitle,
        active: settings.get_boolean('transparency-enabled'),
    });
    transparencyExpander.add_row(transparencySwitch);
    settings.bind(
        'transparency-enabled',
        transparencySwitch,
        'active',
        Gio.SettingsBindFlags.DEFAULT
    );

    const transparencyRowSubtitle = _(
        '0% is opaque and 100% is fully transparent'
    );
    const transparencyRow = addSpinRow(
        transparencyExpander,
        settings,
        {
            key: 'transparency-level',
            title: _('Transparency'),
            subtitle: transparencyRowSubtitle,
            lower: 0,
            upper: 100,
            addRow: row => transparencyExpander.add_row(row),
        },
        connectSettings
    );
    const dynamicTransparencyOptionsButton =
        createDynamicTransparencyOptionsButton(settings, {
            title: _('Dynamic Transparency Options'),
            behaviorKey: 'transparency-dynamic-behavior',
            distanceKey: 'transparency-dynamic-distance',
            levelKey: 'transparency-dynamic-level',
            animationTimeKey: 'transparency-dynamic-animation-time',
        });
    const {
        row: dynamicTransparencyRow,
        toggle: dynamicTransparencyToggle,
    } = addSwitchRow(transparencyExpander, settings, {
        key: 'transparency-on-unmaximized',
        title: _('Dynamic Transparency'),
        subtitle: dynamicTransparencySubtitle,
        addSuffix: row => row.add_suffix(dynamicTransparencyOptionsButton),
        addRow: row => transparencyExpander.add_row(row),
    });
    const updatePanelTransparencyControls = () => {
        const blocked = blurMyShellPanelBlurEnabled();
        const windowsXpThemeEnabled = settings.get_boolean(
            'windows-xp-theme-enabled'
        );
        transparencyExpander.sensitive = !windowsXpThemeEnabled;
        transparencySwitch.sensitive = !blocked &&
            !windowsXpThemeEnabled;
        transparencySwitch.subtitle = blocked
            ? panelBlurTransparencySubtitle
            : transparencySwitchSubtitle;
        transparencyRow.sensitive = !blocked &&
            !windowsXpThemeEnabled && transparencySwitch.active;
        transparencyRow.subtitle = blocked
            ? panelBlurTransparencySubtitle
            : transparencyRowSubtitle;
        dynamicTransparencyRow.sensitive = !blocked &&
            !windowsXpThemeEnabled;
        dynamicTransparencyRow.subtitle = blocked
            ? panelBlurTransparencySubtitle
            : dynamicTransparencySubtitle;
        dynamicTransparencyOptionsButton.sensitive =
            !blocked && !windowsXpThemeEnabled &&
            dynamicTransparencyToggle.active;
    };
    transparencySwitch.connect(
        'notify::active',
        updatePanelTransparencyControls
    );
    dynamicTransparencyToggle.connect(
        'notify::active',
        updatePanelTransparencyControls
    );
    connectSettings(
        settings,
        'changed::windows-xp-theme-enabled',
        updatePanelTransparencyControls
    );
    updatePanelTransparencyControls();

    const customPanelColorSubtitle = _(
        'Use a chosen color instead of the light or dark theme color'
    );
    const customPanelColorSwitch = new Adw.SwitchRow({
        title: _('Custom Taskbar Color'),
        subtitle: customPanelColorSubtitle,
        active: settings.get_boolean(
            'custom-panel-color-enabled'
        ),
    });
    themeRow.add_row(customPanelColorSwitch);
    settings.bind(
        'custom-panel-color-enabled',
        customPanelColorSwitch,
        'active',
        Gio.SettingsBindFlags.DEFAULT
    );
    const customPanelColorRow = addColorRow(
        themeRow,
        settings,
        {
            key: 'custom-panel-color',
            title: _('Taskbar Color'),
            addRow: row => themeRow.add_row(row),
        },
        connectSettings
    );
    const customPanelGradientSwitch = new Adw.SwitchRow({
        title: _('Use Taskbar Gradient'),
        subtitle: _('Blend the taskbar color with a second color'),
        active: settings.get_boolean('custom-panel-gradient-enabled'),
    });
    themeRow.add_row(customPanelGradientSwitch);
    settings.bind(
        'custom-panel-gradient-enabled',
        customPanelGradientSwitch,
        'active',
        Gio.SettingsBindFlags.DEFAULT
    );
    const customPanelGradientColorRow = addColorRow(
        themeRow,
        settings,
        {
            key: 'custom-panel-gradient-color',
            title: _('Taskbar Gradient Color'),
            addRow: row => themeRow.add_row(row),
        },
        connectSettings
    );
    const customPanelGradientDirectionRow = addComboRow(
        themeRow,
        settings,
        {
            key: 'custom-panel-gradient-direction',
            title: _('Taskbar Gradient Direction'),
            subtitle: _('Choose how the gradient flows'),
            choices: [
                {value: 'vertical', label: _('Vertical')},
                {value: 'horizontal', label: _('Horizontal')},
            ],
            addRow: row => themeRow.add_row(row),
        },
        connectSettings
    );
    const customPanelTextColorSubtitle = _(
        'White text uses the dark taskbar theme; black text uses the light taskbar theme'
    );
    const customPanelTextColorRow = addComboRow(
        themeRow,
        settings,
        {
            key: 'panel-theme',
            title: _('Taskbar Text Color'),
            subtitle: customPanelTextColorSubtitle,
            choices: [
                {value: 'dark', label: _('White')},
                {value: 'light', label: _('Black')},
            ],
            addRow: row => themeRow.add_row(row),
        },
        connectSettings
    );
    customPanelTextColorRow.connect('notify::selected', () => {
        if (settings.get_boolean('panel-theme-follow-system')) {
            settings.set_boolean(
                'panel-theme-follow-system',
                false
            );
        }
    });
    const updateCustomPanelColorControls = () => {
        const blocked = blurMyShellPanelBlurEnabled();
        if (blocked && settings.get_boolean('custom-panel-color-enabled'))
            settings.set_boolean('custom-panel-color-enabled', false);
        const customPanelColorEnabled = settings.get_boolean(
            'custom-panel-color-enabled'
        );
        const customPanelGradientEnabled = settings.get_boolean(
            'custom-panel-gradient-enabled'
        );
        const windowsXpThemeEnabled = settings.get_boolean(
            'windows-xp-theme-enabled'
        );
        customPanelColorSwitch.sensitive = !blocked &&
            !windowsXpThemeEnabled;
        customPanelColorSwitch.subtitle = blocked
            ? panelBlurTransparencySubtitle
            : customPanelColorSubtitle;
        customPanelGradientSwitch.visible = customPanelColorEnabled;
        customPanelGradientSwitch.sensitive = !blocked &&
            !windowsXpThemeEnabled && customPanelColorEnabled;
        customPanelGradientColorRow.visible = customPanelColorEnabled &&
            customPanelGradientEnabled;
        customPanelGradientColorRow.sensitive = !blocked &&
            !windowsXpThemeEnabled && customPanelColorEnabled &&
            customPanelGradientEnabled;
        customPanelGradientDirectionRow.visible = customPanelColorEnabled &&
            customPanelGradientEnabled;
        customPanelGradientDirectionRow.sensitive = !blocked &&
            !windowsXpThemeEnabled && customPanelColorEnabled &&
            customPanelGradientEnabled;
        customPanelColorRow.visible = customPanelColorEnabled;
        customPanelColorRow.sensitive = !blocked &&
            !windowsXpThemeEnabled &&
            customPanelColorEnabled;
        customPanelTextColorRow.visible = customPanelColorEnabled;
        customPanelTextColorRow.sensitive = !blocked &&
            !windowsXpThemeEnabled &&
            customPanelColorEnabled;
        customPanelTextColorRow.subtitle = blocked
            ? panelBlurTransparencySubtitle
            : customPanelTextColorSubtitle;
    };
    const syncPanelThemeControls = () => {
        const windowsXpThemeEnabled = settings.get_boolean(
            'windows-xp-theme-enabled'
        );
        themeRow.sensitive = !windowsXpThemeEnabled;
        followSystemThemeSwitch.sensitive = !windowsXpThemeEnabled;
        panelThemeRow.sensitive = !windowsXpThemeEnabled &&
            !followSystemThemeSwitch.active;
    };
    connectSettings(
        settings,
        'changed::windows-xp-theme-enabled',
        () => {
            syncPanelThemeControls();
            updateCustomPanelColorControls();
        }
    );
    connectSettings(
        settings,
        'changed::panel-theme-follow-system',
        syncPanelThemeControls
    );
    syncPanelThemeControls();
    customPanelColorSwitch.connect(
        'notify::active',
        widget => {
            if (widget.active &&
                settings.get_boolean(
                    'panel-theme-follow-system'
                )) {
                settings.set_boolean(
                    'panel-theme-follow-system',
                    false
                );
            }
            updateCustomPanelColorControls();
        }
    );
    customPanelGradientSwitch.connect(
        'notify::active',
        updateCustomPanelColorControls
    );
    updateCustomPanelColorControls();

    const bordersExpander = new Adw.ExpanderRow({
        title: _('Borders'),
        subtitle: _('Choose whether to show a border in light and dark themes'),
    });
    panelAppearanceGroup.add(bordersExpander);

    const darkPanelBorderSwitch = new Adw.SwitchRow({
        title: _('Show Border in Dark Mode'),
        subtitle: _('Display a thin border along the taskbar’s workspace-facing edge'),
        active: settings.get_boolean('panel-border-enabled'),
    });
    bordersExpander.add_row(darkPanelBorderSwitch);
    settings.bind(
        'panel-border-enabled',
        darkPanelBorderSwitch,
        'active',
        Gio.SettingsBindFlags.DEFAULT
    );

    const lightPanelBorderSwitch = new Adw.SwitchRow({
        title: _('Show Border in Light Mode'),
        subtitle: _('Display a thin border along the taskbar’s workspace-facing edge'),
        active: settings.get_boolean(
            'panel-border-light-enabled'
        ),
    });
    bordersExpander.add_row(lightPanelBorderSwitch);
    settings.bind(
        'panel-border-light-enabled',
        lightPanelBorderSwitch,
        'active',
        Gio.SettingsBindFlags.DEFAULT
    );
    const syncPanelBorderControls = () => {
        const enabled = !settings.get_boolean(
            'windows-xp-theme-enabled'
        );
        bordersExpander.sensitive = enabled;
        darkPanelBorderSwitch.sensitive = enabled;
        lightPanelBorderSwitch.sensitive = enabled;
    };
    connectSettings(
        settings,
        'changed::windows-xp-theme-enabled',
        syncPanelBorderControls
    );
    syncPanelBorderControls();

    return {
        syncCustomColor: updateCustomPanelColorControls,
        syncTransparency: updatePanelTransparencyControls,
    };
}
