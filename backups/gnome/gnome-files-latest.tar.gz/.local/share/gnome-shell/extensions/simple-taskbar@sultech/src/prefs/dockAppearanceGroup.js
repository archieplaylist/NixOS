// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (C) 2026 sultech

import Adw from 'gi://Adw';
import Gio from 'gi://Gio';

import {gettext as _} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

import {
    addColorRow,
    addComboRow,
    addSpinRow,
    addSwitchRow,
    createSwitchRow,
} from './preferencesWidgets.js';
import {
    createDynamicTransparencyOptionsButton,
} from './dynamicTransparencyDialog.js';
import {
    MAX_PANEL_HEIGHT,
    MIN_PANEL_HEIGHT,
} from '../shared/panelSizing.js';
import {
    bindThicknessLowerBound,
    createPanelThicknessSizing,
} from './panelThicknessSizing.js';

const DOCK_PANEL_HEIGHT_KEY = 'dock-panel-height';
const DOCK_PANEL_HEIGHT_FOLLOW_KEY = 'dock-panel-height-follow-icon-size';

export function addDockAppearanceGroup({
    page,
    settings,
    connectSettings,
    blurMyShellPanelBlurEnabled,
    dockModeGroup,
    dockPositionRow,
    dockMaxLengthRow,
}) {
    const group = new Adw.PreferencesGroup({
        title: _('Dock Appearance'),
        description: _('Configure the Dock independently of the taskbar.'),
    });
    page.add(group);
    dockModeGroup.remove(dockMaxLengthRow);
    dockModeGroup.remove(dockPositionRow);

    const dockAvailable = () => settings.get_boolean('dock-mode') &&
        !settings.get_boolean('windows-xp-theme-enabled');

    const {
        followSwitch: dockPanelHeightFollowSwitch,
        followsIcons: dockPanelHeightFollowsIcons,
    } = createPanelThicknessSizing(settings, connectSettings, {
        heightKey: DOCK_PANEL_HEIGHT_KEY,
        followKey: DOCK_PANEL_HEIGHT_FOLLOW_KEY,
        followSubtitle: _(
            'Keep the full-width Dock only as thick as its icons need'
        ),
        isActive: () => settings.get_boolean('dock-mode'),
    });
    group.add(dockPanelHeightFollowSwitch);

    const dockPanelHeightRow = addSpinRow(
        group,
        settings,
        {
            key: DOCK_PANEL_HEIGHT_KEY,
            title: _('Dock Thickness'),
            subtitle: _(
                'Oversized icons shrink automatically when the full-width Dock is reduced'
            ),
            lower: MIN_PANEL_HEIGHT,
            upper: MAX_PANEL_HEIGHT,
        },
        connectSettings
    );
    bindThicknessLowerBound(settings, connectSettings, dockPanelHeightRow);
    group.add(dockMaxLengthRow);
    group.add(dockPositionRow);

    const themeExpander = new Adw.ExpanderRow({
        title: _('Theme and Styling'),
        subtitle: _(
            'Choose the Dock theme, colours, gradient, corner radius, and text appearance'
        ),
    });
    group.add(themeExpander);

    const followSystemThemeSwitch = new Adw.SwitchRow({
        title: _('Follow System Theme'),
        subtitle: _('Match the active GNOME Shell theme'),
        active: settings.get_boolean('dock-panel-theme-follow-system'),
    });
    themeExpander.add_row(followSystemThemeSwitch);
    settings.bind(
        'dock-panel-theme-follow-system',
        followSystemThemeSwitch,
        'active',
        Gio.SettingsBindFlags.DEFAULT
    );

    const dockThemeRow = addComboRow(
        themeExpander,
        settings,
        {
            key: 'dock-panel-theme',
            title: _('Dock Theme'),
            subtitle: _('Choose the colour scheme when system matching is off'),
            choices: [
                {value: 'light', label: _('Light')},
                {value: 'dark', label: _('Dark')},
            ],
            addRow: row => themeExpander.add_row(row),
        },
        connectSettings
    );

    addSpinRow(
        themeExpander,
        settings,
        {
            key: 'dock-corner-radius',
            title: _('Dock Corner Radius'),
            subtitle: _(
                'Applies to the floating Dock, including Dynamic and Static Blur'
            ),
            lower: 0,
            upper: 64,
            addRow: row => themeExpander.add_row(row),
        },
        connectSettings
    );

    const transparencySwitchSubtitle = _(
        'Make the Dock background transparent'
    );
    const dynamicTransparencySubtitle = _(
        'Adjust transparency according to the selected window state'
    );
    const panelBlurTransparencySubtitle = _(
        'Disable Blur My Shell panel blur to use this option'
    );
    const transparencyExpander = new Adw.ExpanderRow({
        title: _('Transparency and Blur'),
        subtitle: _('Configure Dock transparency and Blur My Shell integration'),
    });
    group.add(transparencyExpander);

    const transparencySwitch = new Adw.SwitchRow({
        title: _('Enable Transparency'),
        subtitle: transparencySwitchSubtitle,
        active: settings.get_boolean('dock-transparency-enabled'),
    });
    transparencyExpander.add_row(transparencySwitch);
    settings.bind(
        'dock-transparency-enabled',
        transparencySwitch,
        'active',
        Gio.SettingsBindFlags.DEFAULT
    );
    const dockPanelBlurSwitch = createSwitchRow(settings, {
        key: 'dock-panel-blur-enabled',
        title: _('Blur Dock with Blur My Shell'),
        subtitle: _('Apply Blur My Shell panel blur to the Dock'),
    });
    transparencyExpander.add_row(dockPanelBlurSwitch);

    const transparencyRowSubtitle = _(
        '0% is opaque and 100% is fully transparent'
    );
    const transparencyRow = addSpinRow(
        transparencyExpander,
        settings,
        {
            key: 'dock-transparency-level',
            title: _('Transparency'),
            subtitle: transparencyRowSubtitle,
            lower: 0,
            upper: 100,
            addRow: row => transparencyExpander.add_row(row),
        },
        connectSettings
    );
    const dynamicTransparencyOptionsButton =
        createDynamicTransparencyOptionsButton(settings, {
            title: _('Dock Dynamic Transparency Options'),
            behaviorKey: 'dock-transparency-dynamic-behavior',
            distanceKey: 'dock-transparency-dynamic-distance',
            levelKey: 'dock-transparency-dynamic-level',
            animationTimeKey: 'dock-transparency-dynamic-animation-time',
        });
    const {
        row: dynamicTransparencyRow,
        toggle: dynamicTransparencyToggle,
    } = addSwitchRow(transparencyExpander, settings, {
        key: 'dock-transparency-on-unmaximized',
        title: _('Dynamic Transparency'),
        subtitle: dynamicTransparencySubtitle,
        addSuffix: row => row.add_suffix(dynamicTransparencyOptionsButton),
        addRow: row => transparencyExpander.add_row(row),
    });

    const customPanelColorSubtitle = _(
        'Use a chosen color instead of the light or dark theme color'
    );
    const customPanelColorSwitch = new Adw.SwitchRow({
        title: _('Custom Dock Color'),
        subtitle: customPanelColorSubtitle,
        active: settings.get_boolean('dock-custom-panel-color-enabled'),
    });
    themeExpander.add_row(customPanelColorSwitch);
    settings.bind(
        'dock-custom-panel-color-enabled',
        customPanelColorSwitch,
        'active',
        Gio.SettingsBindFlags.DEFAULT
    );

    const customPanelColorRow = addColorRow(
        themeExpander,
        settings,
        {
            key: 'dock-custom-panel-color',
            title: _('Dock Color'),
            addRow: row => themeExpander.add_row(row),
        },
        connectSettings
    );
    const customPanelGradientSwitch = new Adw.SwitchRow({
        title: _('Use Dock Gradient'),
        subtitle: _('Blend the Dock color with a second color'),
        active: settings.get_boolean(
            'dock-custom-panel-gradient-enabled'
        ),
    });
    themeExpander.add_row(customPanelGradientSwitch);
    settings.bind(
        'dock-custom-panel-gradient-enabled',
        customPanelGradientSwitch,
        'active',
        Gio.SettingsBindFlags.DEFAULT
    );
    const customPanelGradientColorRow = addColorRow(
        themeExpander,
        settings,
        {
            key: 'dock-custom-panel-gradient-color',
            title: _('Dock Gradient Color'),
            addRow: row => themeExpander.add_row(row),
        },
        connectSettings
    );
    const customPanelGradientDirectionRow = addComboRow(
        themeExpander,
        settings,
        {
            key: 'dock-custom-panel-gradient-direction',
            title: _('Dock Gradient Direction'),
            subtitle: _('Choose how the gradient flows'),
            choices: [
                {value: 'vertical', label: _('Vertical')},
                {value: 'horizontal', label: _('Horizontal')},
            ],
            addRow: row => themeExpander.add_row(row),
        },
        connectSettings
    );
    const customPanelTextColorSubtitle = _(
        'White text uses the dark Dock theme; black text uses the light Dock theme'
    );
    const customPanelTextColorRow = addComboRow(
        themeExpander,
        settings,
        {
            key: 'dock-panel-theme',
            title: _('Dock Text Color'),
            subtitle: customPanelTextColorSubtitle,
            choices: [
                {value: 'dark', label: _('White')},
                {value: 'light', label: _('Black')},
            ],
            addRow: row => themeExpander.add_row(row),
        },
        connectSettings
    );

    const bordersExpander = new Adw.ExpanderRow({
        title: _('Borders'),
        subtitle: _('Choose whether to show a border in light and dark themes'),
    });
    group.add(bordersExpander);

    const darkPanelBorderSwitch = new Adw.SwitchRow({
        title: _('Show Border in Dark Mode'),
        subtitle: _('Display a thin border along the Dock’s workspace-facing edge'),
        active: settings.get_boolean('dock-panel-border-enabled'),
    });
    bordersExpander.add_row(darkPanelBorderSwitch);
    settings.bind(
        'dock-panel-border-enabled',
        darkPanelBorderSwitch,
        'active',
        Gio.SettingsBindFlags.DEFAULT
    );

    const lightPanelBorderSwitch = new Adw.SwitchRow({
        title: _('Show Border in Light Mode'),
        subtitle: _('Display a thin border along the Dock’s workspace-facing edge'),
        active: settings.get_boolean('dock-panel-border-light-enabled'),
    });
    bordersExpander.add_row(lightPanelBorderSwitch);
    settings.bind(
        'dock-panel-border-light-enabled',
        lightPanelBorderSwitch,
        'active',
        Gio.SettingsBindFlags.DEFAULT
    );

    const syncThemeControls = () => {
        const available = dockAvailable();
        followSystemThemeSwitch.sensitive = available;
        dockThemeRow.sensitive = available &&
            !followSystemThemeSwitch.active;
    };
    const syncTransparencyControls = () => {
        const panelBlurAvailable = blurMyShellPanelBlurEnabled();
        const blocked = settings.get_boolean('dock-panel-blur-enabled') &&
            panelBlurAvailable;
        const available = dockAvailable();
        dockPanelBlurSwitch.sensitive = available && panelBlurAvailable;
        transparencySwitch.sensitive = available && !blocked;
        transparencySwitch.subtitle = blocked
            ? panelBlurTransparencySubtitle
            : transparencySwitchSubtitle;
        transparencyRow.sensitive = available &&
            !blocked && transparencySwitch.active;
        transparencyRow.subtitle = blocked
            ? panelBlurTransparencySubtitle
            : transparencyRowSubtitle;
        dynamicTransparencyRow.sensitive = available && !blocked;
        dynamicTransparencyRow.subtitle = blocked
            ? panelBlurTransparencySubtitle
            : dynamicTransparencySubtitle;
        dynamicTransparencyOptionsButton.sensitive = available &&
            !blocked && dynamicTransparencyToggle.active;
    };
    const syncCustomColorControls = () => {
        const blocked = settings.get_boolean('dock-panel-blur-enabled') &&
            blurMyShellPanelBlurEnabled();
        if (blocked &&
            settings.get_boolean('dock-custom-panel-color-enabled')) {
            settings.set_boolean(
                'dock-custom-panel-color-enabled',
                false
            );
        }
        const available = dockAvailable();
        const enabled = customPanelColorSwitch.active;
        const gradientEnabled = settings.get_boolean(
            'dock-custom-panel-gradient-enabled'
        );
        customPanelColorSwitch.sensitive = available && !blocked;
        customPanelColorSwitch.subtitle = blocked
            ? panelBlurTransparencySubtitle
            : customPanelColorSubtitle;
        customPanelGradientSwitch.visible = enabled;
        customPanelGradientSwitch.sensitive = available &&
            !blocked && enabled;
        customPanelGradientColorRow.visible = enabled && gradientEnabled;
        customPanelGradientColorRow.sensitive = available &&
            !blocked && enabled && gradientEnabled;
        customPanelGradientDirectionRow.visible = enabled &&
            gradientEnabled;
        customPanelGradientDirectionRow.sensitive = available &&
            !blocked && enabled && gradientEnabled;
        customPanelColorRow.visible = enabled;
        customPanelColorRow.sensitive = available &&
            !blocked && enabled;
        customPanelTextColorRow.visible = enabled;
        customPanelTextColorRow.sensitive = available &&
            !blocked && enabled;
        customPanelTextColorRow.subtitle = blocked
            ? panelBlurTransparencySubtitle
            : customPanelTextColorSubtitle;
    };
    const syncAvailability = () => {
        const available = dockAvailable();
        group.sensitive = available;
        const fullWidthDock = settings.get_boolean('dock-panel-mode');
        dockPanelHeightFollowSwitch.sensitive = fullWidthDock;
        dockPanelHeightRow.sensitive = fullWidthDock &&
            !dockPanelHeightFollowsIcons();
        syncThemeControls();
        syncTransparencyControls();
        syncCustomColorControls();
    };

    followSystemThemeSwitch.connect('notify::active', widget => {
        if (widget.active)
            settings.set_boolean('dock-custom-panel-color-enabled', false);
        syncThemeControls();
        syncCustomColorControls();
    });
    transparencySwitch.connect(
        'notify::active',
        syncTransparencyControls
    );
    dynamicTransparencyToggle.connect(
        'notify::active',
        syncTransparencyControls
    );
    customPanelColorSwitch.connect('notify::active', widget => {
        if (widget.active &&
            settings.get_boolean('dock-panel-theme-follow-system')) {
            settings.set_boolean('dock-panel-theme-follow-system', false);
        }
        syncThemeControls();
        syncCustomColorControls();
    });
    customPanelGradientSwitch.connect(
        'notify::active',
        syncCustomColorControls
    );

    for (const key of [
        'dock-mode',
        'dock-panel-mode',
        DOCK_PANEL_HEIGHT_FOLLOW_KEY,
        'windows-xp-theme-enabled',
    ]) {
        connectSettings(settings, `changed::${key}`, syncAvailability);
    }
    connectSettings(
        settings,
        'changed::dock-panel-theme-follow-system',
        syncThemeControls
    );
    connectSettings(
        settings,
        'changed::dock-custom-panel-color-enabled',
        syncCustomColorControls
    );
    connectSettings(
        settings,
        'changed::dock-transparency-enabled',
        syncTransparencyControls
    );
    connectSettings(
        settings,
        'changed::dock-panel-blur-enabled',
        () => {
            syncTransparencyControls();
            syncCustomColorControls();
        }
    );
    syncAvailability();

    return {
        syncTransparency: syncTransparencyControls,
        syncCustomColor: syncCustomColorControls,
    };
}
