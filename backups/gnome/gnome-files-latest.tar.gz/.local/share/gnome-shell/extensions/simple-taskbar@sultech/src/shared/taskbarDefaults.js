// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (C) 2026 sultech

import {DEFAULT_PANEL_ITEM_ORDER} from './panelItemOrder.js';
import {
    APPLICATION_CLICK_ANIMATION,
} from './applicationClickAnimation.js';
import {
    WINDOW_MINIMIZE_EFFECT,
} from './windowMinimizeEffect.js';
import {TASKBAR_HIGHLIGHT_STYLE} from './classicHighlightSettings.js';
import {DEFAULT_ICON_EDGE_PADDING} from './panelSizing.js';
import {applySharedInteractionDefaults} from './interactionDefaults.js';
import {
    setBoolean,
    setInteger,
    setString,
    setStringArray,
} from './settingsUtils.js';

export const DEFAULT_TASKBAR_PANEL_HEIGHT = 51;
export const DEFAULT_TASKBAR_ICON_SIZE = 32;
export const DEFAULT_TASKBAR_ICON_SPACING = 3;
export const DEFAULT_TASKBAR_ALIGNMENT = 'center';
export const DEFAULT_TASKBAR_COMBINE_MODE = 'always';

export function applyDefaultTaskbarSettings(settings) {
    setBoolean(settings, 'panel-height-follow-icon-size', false);
    setInteger(settings, 'panel-height', DEFAULT_TASKBAR_PANEL_HEIGHT);
    setInteger(settings, 'panel-button-padding', -1);
    setInteger(settings, 'icon-size', DEFAULT_TASKBAR_ICON_SIZE);
    setInteger(settings, 'icon-spacing', DEFAULT_TASKBAR_ICON_SPACING);
    setInteger(
        settings,
        'icon-edge-padding',
        DEFAULT_ICON_EDGE_PADDING
    );
    setString(
        settings,
        'taskbar-highlight-style',
        TASKBAR_HIGHLIGHT_STYLE.GLASS
    );
    setInteger(settings, 'start-button-padding', 2);
    setString(settings, 'app-alignment', DEFAULT_TASKBAR_ALIGNMENT);
    setString(settings, 'activities-button-position', 'left');
    setString(settings, 'panel-position', 'bottom');
    setString(settings, 'clock-position', 'right');
    setString(settings, 'system-menu-position', 'right');
    setString(settings, 'folder-menu-position', 'right');
    setString(settings, 'tray-overflow-position', 'right');
    setString(settings, 'show-desktop-button-position', 'right');
    setStringArray(
        settings,
        'panel-item-order',
        DEFAULT_PANEL_ITEM_ORDER
    );
    setString(
        settings,
        'start-button-position',
        DEFAULT_TASKBAR_ALIGNMENT
    );
    setBoolean(settings, 'activities-button-visible', true);
    setBoolean(settings, 'multi-monitor-panels', true);
    setBoolean(settings, 'use-pinned-apps-as-launchers', false);
    setBoolean(settings, 'windows-start-menu-enabled', true);
    setBoolean(settings, 'start-button-follow-app-alignment', true);
    setBoolean(settings, 'gnome-start-button-visible', true);
    setBoolean(settings, 'system-menu-visible', true);
    setBoolean(settings, 'clock-visible', true);
    setBoolean(settings, 'panel-theme-follow-system', true);
    setBoolean(settings, 'transparency-enabled', true);
    setBoolean(settings, 'transparency-on-unmaximized', false);
    setString(
        settings,
        'transparency-dynamic-behavior',
        'maximized-windows'
    );
    setInteger(settings, 'transparency-dynamic-distance', 20);
    setInteger(settings, 'transparency-dynamic-level', 100);
    setInteger(settings, 'transparency-dynamic-animation-time', 300);
    setBoolean(settings, 'panel-border-enabled', false);
    setBoolean(settings, 'panel-border-light-enabled', false);
    setBoolean(settings, 'application-overflow-enabled', true);
    setBoolean(settings, 'hide-app-labels', false);
    setInteger(settings, 'group-apps-label-font-size', 14);
    setString(settings, 'group-apps-label-font-weight', 'inherit');
    setInteger(settings, 'group-apps-label-max-width', 160);
    setBoolean(settings, 'group-apps-use-fixed-width', true);
    setBoolean(settings, 'hide-pinned-taskbar-apps', false);
    setBoolean(settings, 'hide-pinned-secondary-monitors', false);
    setBoolean(settings, 'hide-unpinned-taskbar-apps', false);
    setBoolean(settings, 'super-number-keybindings-enabled', true);
    applySharedInteractionDefaults(settings);
    setString(
        settings,
        'application-click-animation',
        APPLICATION_CLICK_ANIMATION.GNOME_ZOOM_OUT
    );
    setString(
        settings,
        'window-minimize-effect',
        WINDOW_MINIMIZE_EFFECT.GNOME_DEFAULT
    );
    setBoolean(settings, 'start-menu-follow-panel-theme', true);
    setBoolean(settings, 'start-menu-follow-panel-transparency', false);
    setString(
        settings,
        'combine-app-buttons-mode',
        DEFAULT_TASKBAR_COMBINE_MODE
    );
}
