// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (C) 2026 sultech

import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';

import * as Layout from 'resource:///org/gnome/shell/ui/layout.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {
    TransientSignalHolder,
} from 'resource:///org/gnome/shell/misc/signalTracker.js';

import {panelGeometry} from './panelGeometry.js';
import {
    panelIsMinimumEdge,
    panelIsVertical,
    panelPosition,
} from './panelPosition.js';
import {
    destroyPressureBarrier,
    pointerButtonIsPressed,
} from '../pointerUtils.js';
import {
    autoHideHideDelay,
    autoHideRevealDelay,
    autoHideUsesPressure,
} from '../shared/autoHideSettings.js';

const BLOCKED_RECHECK_DELAY = 150;
const ANIMATION_TIME = 180;
const REVEAL_EDGE_SIZE = 2;
const FULLSCREEN_POINTER_POLL_INTERVAL = 20;
const PRESSURE_TIMEOUT = 1000;
const BARRIER_CORNER_INSET = 1;
const BARRIER_DIRECTIONS = {
    top: Meta.BarrierDirection.POSITIVE_Y,
    bottom: Meta.BarrierDirection.NEGATIVE_Y,
    left: Meta.BarrierDirection.POSITIVE_X,
    right: Meta.BarrierDirection.NEGATIVE_X,
};
export class PanelAutoHideController {
    constructor({
        settings,
        panelActor,
        positionActor,
        strutActor = null,
        getMonitor,
        getPanelHeight,
        getPanelLengthPercentage = () => null,
        getPanelLengthOverride = () => null,
        getPanelEdgeGap = () => 0,
        getLimitRevealToPanel = () => true,
        isBlocked,
        getOutwardReserve,
        onHidden,
        onPositionFrame = () => {},
    }) {
        this._settings = settings;
        this._panelActor = panelActor;
        this._positionActor = positionActor;
        this._strutActor = strutActor;
        this._getMonitor = getMonitor;
        this._getPanelHeight = getPanelHeight;
        this._getPanelLengthPercentage = getPanelLengthPercentage;
        this._getPanelLengthOverride = getPanelLengthOverride;
        this._getPanelEdgeGap = getPanelEdgeGap;
        this._getLimitRevealToPanel = getLimitRevealToPanel;
        this._isBlockedCallback = isBlocked;
        this._getOutwardReserve = getOutwardReserve;
        this._onHidden = onHidden;
        this._onPositionFrame = onPositionFrame;
        this._signalHolder = new TransientSignalHolder();
        this._cursorTracker = global.backend.get_cursor_tracker();
        this._cursorPositionInvalidatedId = 0;
        this._hideTimeoutId = 0;
        this._hideAfterReveal = false;
        this._fullscreenWatchId = 0;
        this._fullscreenReleasePending = false;
        this._pointerButtonPressed = false;
        this._hidden = false;
        this._overviewSuspended = false;
        this._overviewEdgeRevealBlocked = false;
        this._trackedActorData = null;
        this._strutActorData = null;
        this._originalAffectsStruts = false;
        this._originalStrutAffectsStruts = false;
        this._originalTrackFullscreen = false;
        this._unredirectDisabled = false;
        this._fullscreenVisibilityHeld = false;
        this._dodgeEnabled = false;
        this._dodgeActive = false;
        this._pointerReveal = false;
        this._positionTarget = null;
        this._positionTargetProperty = null;
        this._revealDwellTimeoutId = 0;
        this._barrier = null;
        this._pressureBarrier = null;
        this._pressureTriggerId = 0;
    }

    enable() {
        this._panelActor.connectObject(
            'enter-event', () => {
                if (!this._overviewEdgeRevealBlocked &&
                    !Main.overview.animationInProgress) {
                    this.show();
                }
                return Clutter.EVENT_PROPAGATE;
            },
            'leave-event', () => {
                this._scheduleHide();
                return Clutter.EVENT_PROPAGATE;
            },
            this._signalHolder
        );
        this._positionActor.connectObject(
            'notify::x', () => this._syncMonitorClip(),
            'notify::y', () => this._syncMonitorClip(),
            'notify::width', () => this._syncMonitorClip(),
            'notify::height', () => this._syncMonitorClip(),
            this._signalHolder
        );
        global.stage.connectObject(
            'captured-event', (_stage, event) => {
                if (event.type() !== Clutter.EventType.MOTION)
                    return Clutter.EVENT_PROPAGATE;

                const [x, y] = event.get_coords();
                this._handlePointerMotion(x, y);
                return Clutter.EVENT_PROPAGATE;
            },
            'notify::key-focus', () => {
                if (this._focusIsInsidePanel())
                    this.show();
                else
                    this._scheduleHide();
            },
            this._signalHolder
        );
        this._settings.connectObject(
            'changed::panel-autohide-enabled', () => this._syncEnabled(),
            'changed::panel-autohide-reveal-mode',
            () => this._syncPressureBarrier(),
            'changed::panel-autohide-pressure-threshold',
            () => this._syncPressureBarrier(),
            'changed::panel-position', () => this._syncPressureBarrier(),
            this._signalHolder
        );
        Main.overview.connectObject(
            'showing', () => this._suspendForOverview(),
            'hiding', () => this._hideForOverview(),
            'hidden', () => this._resumeAfterOverview(),
            this._signalHolder
        );
        global.display.connectObject(
            'in-fullscreen-changed', () => this._fullscreenChanged(),
            this._signalHolder
        );

        this._overviewSuspended = Main.overview.visibleTarget;
        this._overviewEdgeRevealBlocked =
            Main.overview.animationInProgress;
        this._captureStrutTracking();
        this._syncStrutTracking();
        this.syncPosition();
        this._syncEnabled();
    }

    get hidden() {
        return this._hidden;
    }

    destroy() {
        this._clearHideTimeout();
        this._cancelRevealDwell();
        this._destroyPressureBarrier();
        this._stopFullscreenWatch();
        if (this._cursorPositionInvalidatedId)
            this._cursorTracker.disconnect(this._cursorPositionInvalidatedId);
        this._cursorPositionInvalidatedId = 0;
        this._signalHolder.destroy();
        this._signalHolder = null;

        this._restoreFullscreenVisibilityState();
        this._hidden = false;
        this._overviewSuspended = false;
        this._overviewEdgeRevealBlocked = false;
        this._dodgeEnabled = false;
        this._dodgeActive = false;
        this._pointerReveal = false;
        this._positionActor.remove_transition('x');
        this._positionActor.remove_transition('y');
        this.syncPosition();
        this._positionActor.remove_clip();
        this._restoreStrutTracking();
        this._restoreUnredirect();

        this._cursorTracker = null;
        this._settings = null;
        this._panelActor = null;
        this._positionActor = null;
        this._strutActor = null;
        this._getMonitor = null;
        this._getPanelHeight = null;
        this._getPanelLengthPercentage = null;
        this._getPanelLengthOverride = null;
        this._getPanelEdgeGap = null;
        this._getLimitRevealToPanel = null;
        this._isBlockedCallback = null;
        this._getOutwardReserve = null;
        this._onHidden = null;
        this._onPositionFrame = null;
        this._trackedActorData = null;
        this._strutActorData = null;
        this._positionTarget = null;
        this._positionTargetProperty = null;
    }

    setMenuOpen(open) {
        if (open) {
            this._fullscreenReleasePending = false;
            this.show(false);
            const monitor = this._getMonitor();
            if (global.window_group.visible && monitor?.inFullscreen) {
                this._trackedActorData.trackFullscreen = false;
                this._positionActor.visible = true;
                this._fullscreenVisibilityHeld = true;
                this._clearHideTimeout();
                this._syncUnredirect();
                this._startFullscreenWatch();
            }
            return;
        }

        if (this._fullscreenVisibilityHeld)
            return;
        if (this._dodgeEnabled && this._dodgeActive) {
            if (!this._pointerReveal ||
                !this._pointerIsInsidePanel()) {
                if (!this._hidden)
                    this._hide();
            }
            return;
        }
        if (this._enabled() &&
            (!this._pointerReveal || !this._pointerIsInsidePanel())) {
            this._clearHideTimeout();
            this._scheduleHide();
        }
    }

    setDodgeState(enabled, active, pointerReveal) {
        const wasActive = this._dodgeActive;
        this._dodgeEnabled = enabled;
        this._dodgeActive = active;
        this._pointerReveal = pointerReveal;
        this._syncPressureBarrier();
        this._syncPointerWatch();
        if (this._enabled() || enabled)
            this._syncStrutTracking();
        else
            this._restoreStrutTracking();
        this._syncUnredirect();
        if (this._overviewSuspended ||
            this._fullscreenVisibilityHeld) {
            return;
        }

        const fullscreenBlocked = this._fullscreenBlocksReveal();
        if (!active) {
            if (!fullscreenBlocked && !this._enabled())
                this.show();
            else if (!fullscreenBlocked && this._pointerReveal &&
                this._pointerIsInsidePanel())
                this.show();
            else
                this._scheduleHide();
            return;
        }

        if (!fullscreenBlocked && pointerReveal &&
            this._pointerIsInsidePanel()) {
            this.show();
            return;
        }

        if (this._isBlocked()) {
            this._scheduleHide(0);
            return;
        }

        if (!this._hidden) {
            if (wasActive)
                this._scheduleHide();
            else
                this._hide();
        }
        if (pointerReveal) {
            const [x, y] = global.get_pointer();
            this._handlePointerMotion(x, y);
        }
    }

    syncPosition(animate = false) {
        const monitor = this._getMonitor();
        const actor = this._positionActor;
        if (!monitor)
            return;

        const geometry = this._geometry(monitor);
        const offset = this._hidden && (this._enabled() ||
            this._dodgeActive)
            ? geometry.hiddenOffset
            : geometry.visibleOffset;
        const property = geometry.vertical ? 'x' : 'y';
        if (actor.get_transition('x') || actor.get_transition('y')) {
            if (this._positionTarget !== offset ||
                this._positionTargetProperty !== property)
                this._moveTo(offset, true);
            return;
        }
        if (animate) {
            this._moveTo(offset, true);
            return;
        }
        actor.remove_transition('x');
        actor.remove_transition('y');
        actor[property] = offset;
        this._positionTarget = offset;
        this._positionTargetProperty = property;
        this._syncMonitorClip();
        Main.layoutManager._queueUpdateRegions();
    }

    show(animate = true) {
        this._clearHideTimeout();
        this._cancelRevealDwell();
        if (!this._hidden) {
            if (this._shouldScheduleHide())
                this._scheduleHide();
            return;
        }

        this._hidden = false;
        this._syncPressureBarrier();
        this._moveTo(this._geometry(this._getMonitor()).visibleOffset, animate);
        if (this._shouldScheduleHide())
            this._scheduleHide();
    }

    _enabled() {
        return this._settings.get_boolean('panel-autohide-enabled');
    }

    _syncEnabled() {
        this._syncPressureBarrier();
        this._syncPointerWatch();
        this._syncUnredirect();
        if (this._enabled() || this._dodgeEnabled)
            this._syncStrutTracking();
        else
            this._restoreStrutTracking();
        if (this._overviewSuspended) {
            this.show(false);
            return;
        }

        if (this._dodgeActive) {
            if (this._pointerReveal && this._pointerIsInsidePanel())
                this.show(false);
            else if (!this._hidden)
                this._hide(false);
            return;
        }

        if (!this._enabled()) {
            this.show(false);
            return;
        }

        if (this._pointerReveal && this._pointerIsInsidePanel())
            this.show(false);
        else
            this._scheduleHide();
    }

    _pointerRevealEnabled() {
        if (!this._pointerReveal || autoHideUsesPressure(this._settings))
            return false;

        return this._enabled() ||
            this._dodgeEnabled && this._dodgeActive;
    }

    _syncPointerWatch() {
        const shouldWatch = this._enabled() ||
            this._dodgeEnabled && this._dodgeActive &&
            this._pointerReveal;
        if (shouldWatch && !this._cursorPositionInvalidatedId) {
            this._cursorPositionInvalidatedId = this._cursorTracker.connect(
                'position-invalidated',
                () => {
                    const [x, y] = global.get_pointer();
                    this._handlePointerMotion(x, y);
                }
            );
        } else if (!shouldWatch && this._cursorPositionInvalidatedId) {
            this._cursorTracker.disconnect(
                this._cursorPositionInvalidatedId
            );
            this._cursorPositionInvalidatedId = 0;
        }
    }

    _captureStrutTracking() {
        this._trackedActorData = this._captureActorData(
            this._positionActor
        );
        this._originalAffectsStruts =
            this._trackedActorData.affectsStruts;
        this._originalTrackFullscreen =
            this._trackedActorData.trackFullscreen;
        if (!this._strutActor)
            return;

        this._strutActorData = this._captureActorData(this._strutActor);
        this._originalStrutAffectsStruts =
            this._strutActorData.affectsStruts;
    }

    _captureActorData(actor) {
        const index = Main.layoutManager._findActor(actor);
        return Main.layoutManager._trackedActors[index];
    }

    _syncStrutTracking() {
        const panelChanged = this._disableStrutTracking(
            this._trackedActorData
        );
        const strutChanged = this._disableStrutTracking(
            this._strutActorData
        );
        if (panelChanged || strutChanged)
            Main.layoutManager._queueUpdateRegions();
    }

    _restoreStrutTracking() {
        const panelChanged = this._restoreActorStrutTracking(
            this._trackedActorData,
            this._originalAffectsStruts
        );
        const strutChanged = this._restoreActorStrutTracking(
            this._strutActorData,
            this._originalStrutAffectsStruts
        );
        if (panelChanged || strutChanged)
            Main.layoutManager._queueUpdateRegions();
    }

    _disableStrutTracking(actorData) {
        if (!actorData || !actorData.affectsStruts)
            return false;

        actorData.affectsStruts = false;
        return true;
    }

    _restoreActorStrutTracking(actorData, originalAffectsStruts) {
        if (!actorData || actorData.affectsStruts === originalAffectsStruts)
            return false;

        actorData.affectsStruts = originalAffectsStruts;
        return true;
    }

    _disableUnredirect() {
        if (this._unredirectDisabled)
            return;

        global.compositor.disable_unredirect();
        this._unredirectDisabled = true;
    }

    _restoreUnredirect() {
        if (!this._unredirectDisabled)
            return;

        global.compositor.enable_unredirect();
        this._unredirectDisabled = false;
    }

    _syncUnredirect() {
        if (this._fullscreenVisibilityHeld) {
            this._disableUnredirect();
            return;
        }

        if (global.window_group.visible &&
            this._getMonitor()?.inFullscreen) {
            this._restoreUnredirect();
            return;
        }

        if (this._enabled() || this._dodgeEnabled)
            this._disableUnredirect();
        else
            this._restoreUnredirect();
    }

    _restoreFullscreenVisibility() {
        this._stopFullscreenWatch();
        this._restoreFullscreenVisibilityState();
    }

    _restoreFullscreenVisibilityState() {
        if (!this._fullscreenVisibilityHeld)
            return;

        this._fullscreenVisibilityHeld = false;
        const monitor = this._getMonitor();
        this._trackedActorData.trackFullscreen =
            this._originalTrackFullscreen;
        this._positionActor.visible =
            !this._originalTrackFullscreen ||
            !(global.window_group.visible && monitor?.inFullscreen);
        this._syncUnredirect();
    }

    _fullscreenChanged() {
        this._syncUnredirect();
        if (!this._fullscreenVisibilityHeld ||
            this._getMonitor()?.inFullscreen) {
            return;
        }

        this._restoreFullscreenVisibility();
        if ((this._enabled() || this._dodgeActive) &&
            !this._pointerIsInsidePanel())
            this._scheduleHide();
    }

    _startFullscreenWatch() {
        if (this._fullscreenWatchId)
            return;

        this._fullscreenReleasePending = false;
        this._pointerButtonPressed = pointerButtonIsPressed();
        this._fullscreenWatchId = GLib.timeout_add(
            GLib.PRIORITY_DEFAULT,
            FULLSCREEN_POINTER_POLL_INTERVAL,
            () => {
                const pointerPressed = pointerButtonIsPressed();
                if (pointerPressed && !this._pointerButtonPressed) {
                    this._fullscreenReleasePending =
                        !this._pointerIsInsidePanel();
                }
                this._pointerButtonPressed = pointerPressed;

                if (!this._fullscreenReleasePending ||
                    this._isBlockedCallback()) {
                    return GLib.SOURCE_CONTINUE;
                }

                this._fullscreenWatchId = 0;
                this._restoreFullscreenVisibility();
                return GLib.SOURCE_REMOVE;
            }
        );
    }

    _stopFullscreenWatch() {
        if (this._fullscreenWatchId)
            GLib.Source.remove(this._fullscreenWatchId);
        this._fullscreenWatchId = 0;
        this._fullscreenReleasePending = false;
        this._pointerButtonPressed = false;
    }

    _scheduleHide(delay = autoHideHideDelay(this._settings)) {
        const canHide = this._enabled() ||
            this._dodgeEnabled && this._dodgeActive &&
            this._pointerReveal;
        if (!canHide ||
            this._overviewSuspended ||
            this._fullscreenVisibilityHeld || this._hidden ||
            this._hideTimeoutId) {
            return;
        }

        const property = panelIsVertical(this._settings) ? 'x' : 'y';
        if (this._positionActor.get_transition(property)) {
            this._hideAfterReveal = true;
            return;
        }

        this._hideTimeoutId = GLib.timeout_add(
            GLib.PRIORITY_DEFAULT,
            delay,
            () => {
                this._hideTimeoutId = 0;
                const [x, y] = global.get_pointer();
                const canStillHide = this._enabled() ||
                    this._dodgeEnabled && this._dodgeActive &&
                    this._pointerReveal;
                if (!canStillHide ||
                    this._overviewSuspended ||
                    this._pointerIsInsidePanel() ||
                    this._pointerIsAtRevealEdge(x, y)) {
                    return GLib.SOURCE_REMOVE;
                }
                if (this._isBlocked()) {
                    this._scheduleHide(BLOCKED_RECHECK_DELAY);
                    return GLib.SOURCE_REMOVE;
                }

                this._hide();
                return GLib.SOURCE_REMOVE;
            }
        );
    }

    _clearHideTimeout() {
        if (this._hideTimeoutId)
            GLib.Source.remove(this._hideTimeoutId);
        this._hideTimeoutId = 0;
        this._hideAfterReveal = false;
    }

    _suspendForOverview() {
        this._overviewSuspended = true;
        this._overviewEdgeRevealBlocked = true;
        this._clearHideTimeout();
        if (!this._enabled() && !this._dodgeActive)
            return;

        this._hidden = false;
        this._syncPressureBarrier();
        this._moveTo(
            this._geometry(this._getMonitor()).visibleOffset,
            false
        );
    }

    _hideForOverview() {
        this._overviewEdgeRevealBlocked = true;
        this._restoreFullscreenVisibility();
        if ((this._enabled() || this._dodgeActive) && !this._isBlocked())
            this._hide();
    }

    _resumeAfterOverview() {
        if (!this._overviewSuspended)
            return;

        this._overviewSuspended = false;
        if (!this._enabled() && !this._dodgeActive)
            return;
        if (this._isBlocked()) {
            this._scheduleHide();
            return;
        }

        this._hide(false);
    }

    _hide(animate = true) {
        this._hideAfterReveal = false;
        this._hidden = true;
        this._syncPressureBarrier();
        this._moveTo(
            this._geometry(this._getMonitor()).hiddenOffset,
            animate
        );
        this._onHidden();
    }

    _isBlocked() {
        return this._focusIsInsidePanel() ||
            this._isBlockedCallback();
    }

    _shouldScheduleHide() {
        const canHide = this._enabled() ||
            this._dodgeEnabled && this._dodgeActive &&
            this._pointerReveal;
        const [x, y] = global.get_pointer();
        return canHide &&
            !this._pointerIsInsidePanel() &&
            !this._pointerIsAtRevealEdge(x, y);
    }

    _focusIsInsidePanel() {
        const focus = global.stage.get_key_focus();
        return Boolean(
            focus && (focus === this._panelActor ||
                this._panelActor.contains(focus))
        );
    }

    _pointerIsInsidePanel() {
        const monitor = this._getMonitor();
        if (!monitor || this._hidden)
            return false;

        const [x, y] = global.get_pointer();
        const geometry = this._geometry(monitor);
        const reserve = this._getOutwardReserve();
        if (reserve > 0) {
            const vertical = panelIsVertical(this._settings);
            const size = vertical ? 'width' : 'height';
            if (!panelIsMinimumEdge(this._settings))
                geometry[vertical ? 'x' : 'y'] -= reserve;
            geometry[size] += reserve;
        }

        return x >= geometry.x && x < geometry.x + geometry.width &&
            y >= geometry.y && y < geometry.y + geometry.height;
    }

    _pointerIsAtRevealEdge(x, y) {
        const monitor = this._getMonitor();
        if (!monitor)
            return false;

        const geometry = this._geometry(monitor);
        const bounds = this._getLimitRevealToPanel() ? geometry : monitor;
        const minimumEdge = panelIsMinimumEdge(this._settings);
        if (geometry.vertical) {
            if (y < bounds.y || y >= bounds.y + bounds.height)
                return false;
            const edge = minimumEdge
                ? geometry.x
                : geometry.x + geometry.width;
            return minimumEdge
                ? x <= edge + REVEAL_EDGE_SIZE
                : x >= edge - REVEAL_EDGE_SIZE;
        }
        if (x < bounds.x || x >= bounds.x + bounds.width)
            return false;
        const edge = minimumEdge
            ? geometry.y
            : geometry.y + geometry.height;
        return minimumEdge
            ? y <= edge + REVEAL_EDGE_SIZE
            : y >= edge - REVEAL_EDGE_SIZE;
    }

    _handlePointerMotion(x, y) {
        if (Main.overview.animationInProgress)
            return;

        if (!this._hidden) {
            if (!this._pointerIsInsidePanel())
                this._scheduleHide();
            return;
        }

        if (!this._pointerRevealEnabled())
            return;

        if (!this._pointerIsAtRevealEdge(x, y)) {
            this._overviewEdgeRevealBlocked = false;
            this._cancelRevealDwell();
            return;
        }

        if (this._overviewEdgeRevealBlocked)
            return;

        if (this._fullscreenBlocksReveal()) {
            this._cancelRevealDwell();
            return;
        }

        const delay = autoHideRevealDelay(this._settings);
        if (!delay) {
            this.show();
            return;
        }

        this._startRevealDwell(delay);
    }

    _usesPressureReveal() {
        return this._pointerReveal &&
            autoHideUsesPressure(this._settings) &&
            (this._enabled() || this._dodgeEnabled);
    }

    _barriersAreSupported() {
        return Boolean(
            global.backend.capabilities &
            Meta.BackendCapabilities.BARRIERS
        );
    }

    _destroyPressureBarrier() {
        if (this._pressureTriggerId) {
            this._pressureBarrier.disconnect(this._pressureTriggerId);
            this._pressureTriggerId = 0;
        }
        destroyPressureBarrier(this._pressureBarrier, this._barrier);
        this._barrier = null;
        this._pressureBarrier = null;
    }

    _pressureBarrierEdge(monitor) {
        const workArea = Main.layoutManager.getWorkAreaForMonitor(
            monitor.index
        );
        const geometry = this._geometry(monitor);
        const limit = this._getLimitRevealToPanel();
        const position = panelPosition(this._settings);
        if (geometry.vertical) {
            const y1 = limit
                ? geometry.y
                : workArea.y + BARRIER_CORNER_INSET;
            const y2 = limit
                ? geometry.y + geometry.height
                : workArea.y + workArea.height - BARRIER_CORNER_INSET;
            const x = position === 'left'
                ? monitor.x
                : monitor.x + monitor.width;
            return {x1: x, x2: x, y1, y2};
        }

        const x1 = limit
            ? geometry.x
            : workArea.x + BARRIER_CORNER_INSET;
        const x2 = limit
            ? geometry.x + geometry.width
            : workArea.x + workArea.width - BARRIER_CORNER_INSET;
        const y = position === 'top'
            ? monitor.y
            : monitor.y + monitor.height;
        return {x1, x2, y1: y, y2: y};
    }

    _syncPressureBarrier() {
        this._destroyPressureBarrier();
        const monitor = this._getMonitor();
        if (!monitor || !this._hidden || !this._usesPressureReveal() ||
            !this._barriersAreSupported()) {
            return;
        }

        const edge = this._pressureBarrierEdge(monitor);
        if (edge.x1 >= edge.x2 && edge.y1 >= edge.y2)
            return;

        this._barrier = new Meta.Barrier({
            backend: global.backend,
            ...edge,
            directions: BARRIER_DIRECTIONS[panelPosition(this._settings)],
        });
        this._pressureBarrier = new Layout.PressureBarrier(
            this._settings.get_int('panel-autohide-pressure-threshold'),
            PRESSURE_TIMEOUT,
            Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW
        );
        this._pressureBarrier.addBarrier(this._barrier);
        this._pressureTriggerId = this._pressureBarrier.connect(
            'trigger',
            () => this._revealFromPressure()
        );
    }

    _fullscreenBlocksReveal() {
        return global.window_group.visible &&
            Boolean(this._getMonitor()?.inFullscreen);
    }

    _revealFromPressure() {
        if (!this._hidden || this._isBlocked())
            return;
        if (this._fullscreenBlocksReveal())
            return;
        if (Main.overview.visibleTarget ||
            Main.overview.animationInProgress) {
            return;
        }

        this.show();
    }

    _cancelRevealDwell() {
        if (this._revealDwellTimeoutId) {
            GLib.Source.remove(this._revealDwellTimeoutId);
            this._revealDwellTimeoutId = 0;
        }
    }

    _startRevealDwell(delay) {
        if (this._revealDwellTimeoutId)
            return;

        this._revealDwellTimeoutId = GLib.timeout_add(
            GLib.PRIORITY_DEFAULT,
            delay,
            () => {
                this._revealDwellTimeoutId = 0;
                this.show();
                return GLib.SOURCE_REMOVE;
            }
        );
    }

    _geometry(monitor) {
        if (monitor) {
            return panelGeometry(
                this._settings,
                monitor,
                this._getPanelHeight(),
                0,
                this._getPanelLengthPercentage(),
                this._getPanelLengthOverride(),
                this._getPanelEdgeGap()
            );
        }
        const vertical = panelIsVertical(this._settings);
        const offset = vertical
            ? this._positionActor.x
            : this._positionActor.y;
        return {
            vertical,
            visibleOffset: offset,
            hiddenOffset: offset,
        };
    }

    _syncMonitorClip() {
        const actor = this._positionActor;
        const monitor = this._getMonitor();
        if (!monitor) {
            actor.remove_clip();
            return;
        }

        const vertical = panelIsVertical(this._settings);
        const offset = vertical ? actor.x : actor.y;
        const size = vertical ? actor.width : actor.height;
        const monitorStart = vertical ? monitor.x : monitor.y;
        const monitorSize = vertical ? monitor.width : monitor.height;
        const clipStart = Math.max(0, monitorStart - offset);
        const clipEnd = Math.min(size, monitorStart + monitorSize - offset);
        if (clipStart <= 0 && clipEnd >= size) {
            actor.remove_clip();
            return;
        }

        const clipSize = Math.max(0, clipEnd - clipStart);
        if (vertical)
            actor.set_clip(clipStart, 0, clipSize, actor.height);
        else
            actor.set_clip(0, clipStart, actor.width, clipSize);
    }

    _moveTo(offset, animate) {
        const actor = this._positionActor;
        if (!actor || offset === undefined)
            return;

        const vertical = panelIsVertical(this._settings);
        const property = vertical ? 'x' : 'y';
        this._positionTarget = offset;
        this._positionTargetProperty = property;
        actor.remove_transition('x');
        actor.remove_transition('y');
        if (!animate) {
            actor[property] = offset;
            this._syncMonitorClip();
            Main.layoutManager._queueUpdateRegions();
            return;
        }

        let transition = null;
        let frameId = 0;
        const params = {
            duration: ANIMATION_TIME,
            mode: Clutter.AnimationMode.EASE_OUT_QUAD,
            onStopped: () => {
                if (frameId)
                    transition.disconnect(frameId);
                frameId = 0;
            },
            onComplete: () => {
                this._syncMonitorClip();
                Main.layoutManager._queueUpdateRegions();
                if (!this._hidden && this._hideAfterReveal) {
                    this._hideAfterReveal = false;
                    this._scheduleHide();
                }
            },
        };
        params[property] = offset;
        actor.ease(params);
        transition = actor.get_transition(property);
        if (transition)
            frameId = transition.connect_after('new-frame', this._onPositionFrame);
    }
}
