// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (C) 2026 sultech

import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import Gtk from 'gi://Gtk';

import {gettext as _} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

import {resolveTaskManagerAppId} from '../shared/taskManagerUtils.js';
import {PANEL_SCROLL_ACTION} from '../shared/panelScrollActions.js';
import {
    addComboRow,
    addSpinRow,
    createSwitchRow,
} from './preferencesWidgets.js';
import {addWindowDodgeRows} from './windowDodgeGroup.js';
import {
    AUTO_HIDE_REVEAL_MODE,
    AUTO_HIDE_SETTINGS,
} from '../shared/autoHideSettings.js';
import {createBottomHotEdgeRow} from './bottomHotEdgeRow.js';

export function getPanelScrollActionChoices() {
    return [
        {
            value: PANEL_SCROLL_ACTION.SWITCH_WORKSPACE,
            label: _('Switch Workspace'),
        },
        {
            value: PANEL_SCROLL_ACTION.CYCLE_WINDOWS,
            label: _('Cycle Windows'),
        },
        {
            value: PANEL_SCROLL_ACTION.CHANGE_VOLUME,
            label: _('Change Volume'),
        },
        {
            value: PANEL_SCROLL_ACTION.DO_NOTHING,
            label: _('Do Nothing'),
        },
    ];
}

export function addTaskbarBehaviorGroup({
    page,
    settings,
    connectSettings,
    isolateMonitorsSwitch,
}) {
    const behaviorGroup = new Adw.PreferencesGroup({
        title: _('Taskbar Behavior'),
    });
    page.add(behaviorGroup);

    const panelAutoHideSwitch = createSwitchRow(settings, {
        key: 'panel-autohide-enabled',
        title: _('Auto-hide Taskbar'),
        subtitle: _('Reveal the taskbar when the pointer reaches its screen edge'),
    });
    addWindowDodgeRows(
        behaviorGroup,
        settings,
        {
            enabledKey: 'panel-dodge-windows-enabled',
            modeKey: 'panel-dodge-windows-mode',
            pointerRevealKey: 'panel-dodge-pointer-reveal-enabled',
            autohideKey: 'panel-autohide-enabled',
            autohideSwitch: panelAutoHideSwitch,
            visibilityTitle: _('Taskbar Auto-hide and Window Dodge'),
            visibilitySubtitle: _(
                'Choose when the taskbar hides and how it is revealed'
            ),
            dodgeSubtitle: _(
                'Hide the taskbar when a qualifying window overlaps it'
            ),
            modeSubtitle: _(
                'Choose which windows make the taskbar hide'
            ),
            pointerRevealSubtitle: _(
                'Let the pointer reveal the hidden taskbar at its screen edge'
            ),
            timingDescriptions: {
                reveal: _(
                    'Choose how quickly the pointer brings the taskbar back'
                ),
                revealMode: _(
                    'Choose when the taskbar appears at the screen edge'
                ),
                hide: _('Choose how soon the taskbar hides again'),
                hideDelay: _(
                    'How long the taskbar waits after the pointer leaves, in milliseconds'
                ),
            },
            visibilityRows: [],
            connectSettings,
        }
    );

    behaviorGroup.add(createBottomHotEdgeRow(settings, connectSettings));
    const disablePressureWithHotEdge = () => {
        if (!settings.get_boolean('hot-edge-overview-enabled'))
            return;

        if (settings.get_string(AUTO_HIDE_SETTINGS.revealMode) ===
            AUTO_HIDE_REVEAL_MODE.PRESSURE) {
            settings.set_string(
                AUTO_HIDE_SETTINGS.revealMode,
                AUTO_HIDE_REVEAL_MODE.INSTANT
            );
        }
    };
    connectSettings(
        settings,
        'changed::hot-edge-overview-enabled',
        disablePressureWithHotEdge
    );
    disablePressureWithHotEdge();

    const workspaceScrollRow = new Adw.ExpanderRow({
        title: _('Taskbar Scroll'),
        subtitle: _('Configure scrolling over empty taskbar space'),
    });
    const workspaceScrollActionRow = addComboRow(
        workspaceScrollRow,
        settings,
        {
            key: 'workspace-scroll-action',
            title: _('Scroll Action'),
            subtitle: _('Action used when scrolling over empty taskbar space'),
            choices: getPanelScrollActionChoices(),
            addRow: row => workspaceScrollRow.add_row(row),
        },
        connectSettings
    );

    const workspaceScrollDelayRow = addSpinRow(
        workspaceScrollRow,
        settings,
        {
            key: 'workspace-scroll-delay',
            title: _('Scroll Delay'),
            subtitle: _('Minimum delay between taskbar scroll actions in milliseconds'),
            lower: 5,
            upper: 250,
            step: 5,
            addRow: row => workspaceScrollRow.add_row(row),
        },
        connectSettings
    );
    behaviorGroup.add(workspaceScrollRow);
    const syncWorkspaceScrollDelaySensitivity = () => {
        workspaceScrollDelayRow.sensitive =
            settings.get_string('workspace-scroll-action') !==
            PANEL_SCROLL_ACTION.DO_NOTHING;
    };
    connectSettings(
        settings,
        'changed::workspace-scroll-action',
        syncWorkspaceScrollDelaySensitivity
    );
    syncWorkspaceScrollDelaySensitivity();

    const panelNotificationRow = new Adw.ExpanderRow({
        title: _('Taskbar Menus and Notifications'),
        subtitle: _(
            'Configure taskbar menu activation and notification banner placement'
        ),
    });
    const panelMenuClickOnlySwitch = createSwitchRow(settings, {
        key: 'panel-menu-click-only',
        title: _('Taskbar Menus Require Click'),
        subtitle: _('Switch between clock, system, and tray menus only when clicked'),
    });
    panelNotificationRow.add_row(panelMenuClickOnlySwitch);

    const notificationBannerSwitch = createSwitchRow(settings, {
        key: 'notification-banner-bottom-end',
        title: _('Taskbar-aligned Notification Banners'),
        subtitle: _('Follow the taskbar edge and the clock position'),
    });
    panelNotificationRow.add_row(notificationBannerSwitch);
    behaviorGroup.add(panelNotificationRow);

    const allTaskManagerApps = Gio.AppInfo.get_all();
    const taskManagerApps = allTaskManagerApps
        .filter(app => app.should_show() && app.get_id())
        .map(app => ({
            value: app.get_id(),
            label: app.get_display_name() ?? app.get_name() ?? app.get_id(),
        }))
        .sort((a, b) => a.label.localeCompare(b.label));
    const configuredTaskManager = settings.get_string(
        'task-manager-app'
    );
    const availableTaskManagerIds = new Set(
        allTaskManagerApps
            .map(app => app.get_id())
            .filter(Boolean)
    );
    const effectiveTaskManager = resolveTaskManagerAppId(
        configuredTaskManager,
        availableTaskManagerIds
    );
    if (!taskManagerApps.some(app =>
        app.value === configuredTaskManager)) {
        taskManagerApps.unshift({
            value: configuredTaskManager,
            label: _('Automatic Fallback'),
        });
    }
    const taskManagerAppRow = addComboRow(
        behaviorGroup,
        settings,
        {
            key: 'task-manager-app',
            title: _('Task Manager Application'),
            subtitle: _('Application opened from the taskbar context menu'),
            choices: taskManagerApps,
            initialValue: effectiveTaskManager ?? configuredTaskManager,
            configureDropDown: dropDown => {
                dropDown.expression = Gtk.PropertyExpression.new(
                    Gtk.StringObject.$gtype,
                    null,
                    'string'
                );
                dropDown.search_match_mode =
                    Gtk.StringFilterMatchMode.SUBSTRING;
                dropDown.enable_search = true;
            },
        },
        connectSettings
    );

    const multiMonitorPanelsSwitch = createSwitchRow(settings, {
        key: 'multi-monitor-panels',
        title: _('Show Taskbar on All Monitors'),
        subtitle: _('Show Activities, applications, clock, and system menu on every monitor'),
    });
    behaviorGroup.add(multiMonitorPanelsSwitch);
    const syncMonitorIsolationSensitivity = () => {
        isolateMonitorsSwitch.sensitive =
            settings.get_boolean('multi-monitor-panels');
    };
    connectSettings(
        settings,
        'changed::multi-monitor-panels',
        syncMonitorIsolationSensitivity
    );
    syncMonitorIsolationSensitivity();
}
